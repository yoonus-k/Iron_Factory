# 📦 نظام أذون التسليم الموحد - Unified Delivery Notes System

## نظرة عامة - Overview

تم تطوير نظام أذون تسليم موحد يدعم كل من **أذون الاستقبال الواردة** (من الموردين) و **أذون التسليم الصادرة** (للزبائن) في نفس النظام.

A unified delivery notes system has been implemented to support both **incoming delivery notes** (from suppliers) and **outgoing delivery notes** (to customers) in a single system.

---

## 🎯 الميزات الرئيسية - Key Features

### 1. **نوع الأذن المرن - Flexible Note Type**
- 🔽 **أذن واردة (Incoming)**: استقبال مواد من الموردين
- 🔼 **أذن صادرة (Outgoing)**: تسليم مواد للزبائن
- النموذج يتكيف تلقائياً بناءً على نوع الأذن المختار

### 2. **تسجيل الأوزان الفعلية - Actual Weight Recording**
- تسجيل الوزن الفعلي من الميزان بشكل منفصل
- تسجيل وزن الفاتورة (اختياري) للمقارنة
- **حساب تلقائي لفرق الأوزان** (الفعلي - الفاتورة)
- يساعد في كشف الاختلافات مع الموردين

### 3. **بيانات مخصصة للنوع - Type-Specific Data**

#### للأذن الواردة (Incoming):
- اختيار المورد
- بيانات السائق واسمه
- رقم المركبة
- رقم مرجع الفاتورة من المورد

#### للأذن الصادرة (Outgoing):
- اختيار المستودع/الوجهة
- اختيار المستقبل/الموظف
- معلومات التسليم

### 4. **نظام التسجيل غير المحجوب - Non-Blocking Logging**
- تسجيل العمليات لا يؤثر على إتمام العملية الأساسية
- إذا حدث خطأ في التسجيل، العملية تكتمل لكن يتم تسجيل الخطأ
- ضمان عدم فقدان البيانات

### 5. **إضافة تفاصيل الفاتورة لاحقاً - Add Invoice Details Later**
- يمكن إنشاء الأذن بدون فاتورة
- يمكن إضافة تفاصيل الفاتورة لاحقاً من قبل المحاسب
- طريقة منفصلة: `addInvoiceDetails()`

---

## 📊 هيكل قاعدة البيانات - Database Schema

### جدول `delivery_notes`

```sql
CREATE TABLE delivery_notes (
    id BIGINT PRIMARY KEY,
    note_number VARCHAR(100) UNIQUE,
    type ENUM('incoming', 'outgoing') DEFAULT 'incoming',
    material_id BIGINT,
    
    -- Weight Information
    delivered_weight DECIMAL(10, 3),        -- الوزن المسلم
    actual_weight DECIMAL(10, 3),           -- الوزن الفعلي من الميزان
    invoice_weight DECIMAL(10, 3),          -- وزن الفاتورة
    weight_discrepancy DECIMAL(10, 3),      -- الفرق (فعلي - فاتورة)
    
    -- Delivery Information
    delivery_date DATE,
    driver_name VARCHAR(255),
    driver_name_en VARCHAR(255),
    vehicle_number VARCHAR(50),
    
    -- Users
    received_by BIGINT,                     -- من استقبل/تسلم
    recorded_by BIGINT,                     -- من سجل الأذن
    approved_by BIGINT,                     -- من وافق
    
    -- Supplier (for incoming)
    supplier_id BIGINT,
    
    -- Destination (for outgoing)
    destination_id BIGINT,
    
    -- Invoice Details
    invoice_number VARCHAR(100),
    invoice_reference_number VARCHAR(100),
    approved_at TIMESTAMP,
    
    -- Status
    is_active BOOLEAN DEFAULT true,
    
    -- Timestamps
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);
```

---

## 🔗 العلاقات - Relationships

### DeliveryNote Model
```php
// Material
deliveryNote->material()

// Users
deliveryNote->receiver()         // من استقبل الأذن
deliveryNote->recordedBy()       // من سجل الأذن
deliveryNote->approvedBy()       // من وافق على الأذن

// Supplier (للأذن الواردة)
deliveryNote->supplier()

// Destination Warehouse (للأذن الصادرة)
deliveryNote->destination()
```

---

## 🎨 واجهة المستخدم - User Interface

### نموذج الإنشاء - Create Form

#### 1. اختيار النوع - Type Selection
```
○ أذن واردة (من المورد)
○ أذن صادرة (للزبون)
```

#### 2. البيانات الأساسية - Basic Information
- رقم الأذن (فريد)
- التاريخ
- المادة

#### 3. معلومات الأوزان - Weight Information
- الوزن الفعلي من الميزان (إجباري)
- وزن الفاتورة (اختياري)
- الفرق يُحسب تلقائياً

#### 4. البيانات المخصصة - Type-Specific Fields
**للأذن الواردة:**
- المورد (إجباري)
- اسم السائق
- رقم المركبة
- رقم مرجع الفاتورة

**للأذن الصادرة:**
- المستودع/الوجهة (إجباري)
- المستقبل

---

## 💻 API والمسارات - Routes & API

### المسارات الأساسية - Basic Routes

```php
// إنشاء أذن جديدة
POST   /delivery-notes

// عرض قائمة الأذون
GET    /delivery-notes

// عرض أذن محددة
GET    /delivery-notes/{id}

// تعديل أذن
PUT    /delivery-notes/{id}

// حذف أذن
DELETE /delivery-notes/{id}

// تغيير الحالة (مفعلة/معطلة)
PUT    /delivery-notes/{id}/toggle-status

// إضافة تفاصيل الفاتورة
POST   /delivery-notes/{id}/add-invoice-details
```

---

## 🔧 المتغيرات والعمليات - Methods & Operations

### في نموذج DeliveryNote

```php
// التحقق من نوع الأذن
$deliveryNote->isIncoming()    // true إذا كانت واردة
$deliveryNote->isOutgoing()    // true إذا كانت صادرة

// حساب الفرق
$deliveryNote->calculateDiscrepancy()  // يُحسب تلقائياً عند الحفظ

// التصفية حسب النوع
DeliveryNote::incoming()->get()   // جميع الأذون الواردة
DeliveryNote::outgoing()->get()   // جميع الأذون الصادرة
```

### في التحكم - DeliveryNoteController

```php
// تخزين أذن جديدة
store($request)

// تحديث أذن موجودة
update($request, $id)

// حذف أذن
destroy($id)

// تبديل الحالة
toggleStatus($request, $id)

// إضافة تفاصيل الفاتورة لاحقاً
addInvoiceDetails($request, $id)
```

---

## 📝 مثال على الاستخدام - Usage Example

### إنشاء أذن واردة - Create Incoming Note
```php
$data = [
    'type' => 'incoming',
    'delivery_number' => 'DN-INC-001-2025',
    'delivery_date' => '2025-11-16',
    'material_id' => 1,
    'actual_weight' => 1000.50,          // من الميزان
    'invoice_weight' => 950.00,          // من الفاتورة
    'supplier_id' => 5,
    'driver_name' => 'أحمد محمد',
    'vehicle_number' => 'أب ت 1234',
    'invoice_reference_number' => 'INV-2025-5678'
];

$deliveryNote = DeliveryNote::create($data);
// weight_discrepancy سيُحسب تلقائياً: 1000.50 - 950.00 = 50.50
```

### إضافة تفاصيل الفاتورة لاحقاً - Add Invoice Later
```php
$deliveryNote->addInvoiceDetails([
    'invoice_number' => 'INV-25-11-001',
    'invoice_weight' => 950.00
]);
```

---

## 🚀 التكامل مع النظام الأكبر - System Integration

### مع نظام تسجيل العمليات - With Operation Logging

كل عملية (إنشاء، تحديث، حذف) تُسجل تلقائياً:
```
- العملية (create, update, delete)
- الوصف (بالعربية والإنجليزية)
- البيانات السابقة والجديدة
- المستخدم الذي قام بالعملية
- التوقيت
```

### مع نظام الأذونات - With Permission System

يمكن إضافة أذونات:
```php
Route::resource('delivery-notes', DeliveryNoteController::class)
    ->middleware('can:manage-delivery-notes');
```

---

## 📊 التقارير المحتملة - Potential Reports

### 1. **تقرير فروقات الأوزان - Weight Discrepancy Report**
يظهر:
- الأذون ذات الفروقات العالية
- الموردين الذين لديهم فروقات متكررة
- إجمالي الفروقات حسب المورد

### 2. **تقرير الأذون المعلقة - Pending Notes Report**
يظهر:
- الأذون التي لم تُموافق عليها بعد
- الأذون المعطلة
- الأذون الجديدة

### 3. **تقرير الأداء - Performance Report**
يظهر:
- عدد الأذون الواردة والصادرة
- سرعة المعالجة
- معدل الأخطاء

---

## 🔐 أمان النظام - Security

### التحقق من البيانات - Validation
```php
'type' => 'required|in:incoming,outgoing',
'actual_weight' => 'required|numeric|gt:0',
'supplier_id' => $type === 'incoming' ? 'required|exists:suppliers,id' : 'nullable',
'destination_id' => $type === 'outgoing' ? 'required|exists:warehouses,id' : 'nullable',
```

### التسجيل - Logging
- كل عملية تُسجل مع بيانات المستخدم
- يمكن تتبع من غيّر ماذا ومتى

---

## 🐛 المعالجة الخاصة بالأخطاء - Error Handling

جميع الأخطاء محبوكة في try-catch blocks:
```php
try {
    // العملية الأساسية
    $deliveryNote->save();
    
} catch (Exception $e) {
    // تسجيل الخطأ بدون إيقاف العملية
    Log::error('Delivery note save failed: ' . $e->getMessage());
    return redirect()->back()->with('error', 'فشل حفظ الأذن');
}
```

---

## 📋 المتطلبات المستقبلية - Future Requirements

### المرحلة 2 - Phase 2

1. **نظام الموافقة** - Approval Workflow
   - موافقة المشرف للأذون الواردة
   - موافقة مدير الإنتاج للأوزان العالية

2. **التكامل مع النظام المحاسبي** - Accounting Integration
   - تصدير البيانات للنظام المحاسبي
   - تسوية الحسابات

3. **التقارير المتقدمة** - Advanced Reports
   - تقارير الأداء
   - تحليل الموردين
   - توقعات الاحتياجات

4. **التنبيهات** - Alerts
   - تنبيهات الفروقات العالية
   - تنبيهات التأخير
   - تنبيهات الموردين المتكررين

---

## 📞 الدعم والمساعدة - Support

للمزيد من المعلومات أو الدعم:
- تحقق من ملف `README.md`
- راجع دليل المستخدم
- تواصل مع فريق التطوير

---

**آخر تحديث:** 16 نوفمبر 2025  
**الإصدار:** 1.0  
**الحالة:** مكتمل وجاهز للاستخدام ✅
