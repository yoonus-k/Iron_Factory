# تحليل الاجتماع الثالث - نظام مصنع الحديد
## Iron Factory Meeting #3 - Complete Analysis & Requirements

**التاريخ:** 22 نوفمبر 2025  
**المشاركون:** Speaker 1 (العميل/المالك), Speaker 2 (مدير الإنتاج), Speaker 3 (مدير المخازن)

---

## 📋 ملخص تنفيذي (Executive Summary)

هذا الاجتماع ركز على تفاصيل عمليات الإنتاج والمخازن في مصنع الحديد، خاصة:
- **نظام إذن الصرف والتسليم** للمنتجات النهائية
- **تتبع دفعات الإنتاج** (Batch Tracking) وربطها بالكويلات المستخدمة
- **حسابات التكلفة والهالك** في مراحل الإنتاج المختلفة
- **نسب الهالك القياسية** لكل مرحلة إنتاجية
- **إدارة المخزون** بين المخازن المختلفة

---

## 🎯 User Stories

### Epic 1: نظام إذن الصرف والتسليم (Delivery Notes System)

#### Story 1.1: إنشاء إذن صرف للعميل
```
كمدير مبيعات
أريد إنشاء إذن صرف للعميل من المخزن
حتى أتمكن من توثيق خروج المنتجات وتسليمها للعميل
```

**معايير القبول:**
- ✅ يجب تسجيل بيانات العميل (الاسم، رقم الهاتف، العنوان)
- ✅ يجب اختيار المنتج من المخزن المتاح
- ✅ يجب تسجيل الكمية المطلوبة والكمية المتاحة
- ✅ يجب حساب التكلفة الإجمالية تلقائياً
- ✅ يجب إنشاء رقم إذن صرف فريد (مثال: 2025-019)
- ✅ يجب طباعة الإذن للتوقيع والتسليم

**الأولوية:** 🔴 عالية جداً

---

#### Story 1.2: تتبع حالة إذن الصرف
```
كمدير مخزن
أريد تتبع حالة إذن الصرف من الإنشاء حتى التسليم
حتى أعرف أي الطلبات قيد التنفيذ وأيها تم تسليمها
```

**معايير القبول:**
- ✅ حالات الإذن: (قيد الإعداد، جاهز للتسليم، تم التسليم، ملغي)
- ✅ يجب تسجيل تاريخ ووقت كل تغيير في الحالة
- ✅ يجب تسجيل المستخدم الذي قام بتغيير الحالة
- ✅ عند التسليم، يجب خصم الكمية من المخزن تلقائياً

**الأولوية:** 🔴 عالية

---

### Epic 2: تتبع دفعات الإنتاج (Production Batch Tracking)

#### Story 2.1: ربط المنتج النهائي بالكويلة المستخدمة
```
كمدير إنتاج
أريد تتبع أي كويلة خام تم استخدامها لإنتاج كل منتج نهائي
حتى أتمكن من حساب التكلفة الفعلية والهالك لكل دفعة
```

**معايير القبول:**
- ✅ عند بدء الإنتاج، يجب اختيار الكويلة الخام من المخزن
- ✅ يجب تسجيل رقم الكويلة (Coil Number) ووزنها الأصلي
- ✅ يجب تسجيل تاريخ بدء الإنتاج
- ✅ يجب ربط جميع المنتجات الناتجة بنفس رقم الكويلة
- ✅ يجب حساب الوزن المستخدم والوزن المتبقي من الكويلة

**الأولوية:** 🔴 عالية جداً

**مثال من الاجتماع:**
```
كويلة رقم: 2005
الوزن الأصلي: 29,500 كجم
تم إنتاج منها: سلك شوك 14 ملم
الكمية المنتجة: 1,850 كجم
الهالك المتوقع: 5-7%
```

---

#### Story 2.2: حساب نسب الهالك لكل مرحلة إنتاجية
```
كمحاسب تكاليف
أريد معرفة نسبة الهالك الفعلية لكل مرحلة إنتاجية
حتى أقارنها بالنسب القياسية وأحسب الانحرافات
```

**معايير القبول:**
- ✅ يجب تسجيل الوزن الداخل والوزن الخارج لكل مرحلة
- ✅ يجب حساب نسبة الهالك تلقائياً: `(الوزن الداخل - الوزن الخارج) / الوزن الداخل × 100`
- ✅ يجب مقارنة النسبة الفعلية بالنسبة القياسية
- ✅ يجب إظهار تنبيه إذا تجاوزت النسبة الحد المسموح

**النسب القياسية من الاجتماع:**
| المرحلة | النسبة القياسية |
|---------|-----------------|
| السحب (Drawing) | 5-7% |
| الجلفنة | 3-5% |
| التشكيل | 2-3% |
| القص | 1-2% |

**الأولوية:** 🟡 متوسطة

---

### Epic 3: إدارة المخزون بين المراحل

#### Story 3.1: نقل المواد بين المخازن
```
كمدير مخزن
أريد نقل المواد من مخزن المواد الخام إلى مخزن تحت التشغيل
حتى أتتبع حركة المواد عبر مراحل الإنتاج المختلفة
```

**معايير القبول:**
- ✅ يجب اختيار المخزن المصدر والمخزن الوجهة
- ✅ يجب اختيار المادة والكمية المراد نقلها
- ✅ يجب التحقق من توفر الكمية في المخزن المصدر
- ✅ يجب خصم الكمية من المصدر وإضافتها للوجهة تلقائياً
- ✅ يجب إنشاء سجل نقل (Transfer Log) مع التاريخ والمستخدم

**الأولوية:** 🟢 عادية

---

#### Story 3.2: جرد المخزون الدوري
```
كمدير مخزن
أريد إجراء جرد دوري للمخزون
حتى أتأكد من تطابق الكميات الفعلية مع السجلات
```

**معايير القبول:**
- ✅ يجب إنشاء جلسة جرد جديدة
- ✅ يجب تسجيل الكمية الفعلية لكل مادة
- ✅ يجب حساب الفروقات تلقائياً
- ✅ يجب تسجيل أسباب الفروقات (هالك، سرقة، خطأ تسجيل)
- ✅ يجب اعتماد الجرد من المدير لتحديث السجلات

**الأولوية:** 🟢 عادية

---

### Epic 4: التقارير والتحليلات

#### Story 4.1: تقرير تكلفة الإنتاج لكل دفعة
```
كمدير مالي
أريد تقرير مفصل عن تكلفة إنتاج كل دفعة
حتى أحلل ربحية المنتجات وأتخذ قرارات التسعير
```

**معايير القبول:**
- ✅ يجب إظهار تكلفة المواد الخام المستخدمة
- ✅ يجب إظهار تكلفة الهالك لكل مرحلة
- ✅ يجب إظهار التكلفة الإجمالية للدفعة
- ✅ يجب حساب تكلفة الوحدة (للكيلو أو القطعة)
- ✅ يجب إمكانية المقارنة بين دفعات مختلفة

**الأولوية:** 🟡 متوسطة

---

#### Story 4.2: تقرير حركة المخزون
```
كمدير عام
أريد تقرير يومي/أسبوعي بحركة المخزون
حتى أراقب مستويات المخزون وأتخذ قرارات الشراء
```

**معايير القبول:**
- ✅ يجب إظهار الرصيد الافتتاحي والختامي
- ✅ يجب إظهار الوارد والصادر لكل مادة
- ✅ يجب إظهار المواد التي وصلت لحد إعادة الطلب
- ✅ يجب إمكانية التصفية حسب المخزن أو نوع المادة
- ✅ يجب إمكانية التصدير لـ PDF أو Excel

**الأولوية:** 🟢 عادية

---

## 🗄️ تصميم قاعدة البيانات (Database Design)

### الجداول الجديدة المطلوبة

#### 1. جدول `delivery_notes` (إذن الصرف)
```sql
CREATE TABLE delivery_notes (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    delivery_note_number VARCHAR(50) UNIQUE NOT NULL, -- مثل: 2025-019
    delivery_type ENUM('outgoing', 'return') DEFAULT 'outgoing',
    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(50),
    customer_address TEXT,
    material_id BIGINT UNSIGNED NOT NULL,
    warehouse_id BIGINT UNSIGNED NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    unit_price DECIMAL(10,2),
    total_amount DECIMAL(12,2),
    status ENUM('draft', 'ready', 'delivered', 'cancelled') DEFAULT 'draft',
    prepared_by BIGINT UNSIGNED, -- user_id
    delivered_by BIGINT UNSIGNED, -- user_id
    prepared_at TIMESTAMP,
    delivered_at TIMESTAMP,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (material_id) REFERENCES materials(id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(id),
    FOREIGN KEY (prepared_by) REFERENCES users(id),
    FOREIGN KEY (delivered_by) REFERENCES users(id),
    
    INDEX idx_delivery_number (delivery_note_number),
    INDEX idx_customer (customer_name),
    INDEX idx_status (status),
    INDEX idx_date (created_at)
);
```

**الأعمدة الرئيسية:**
- `delivery_note_number`: رقم فريد لكل إذن صرف
- `delivery_type`: نوع الإذن (صادر للعميل أو مرتجع)
- `status`: حالة الإذن (مسودة، جاهز، تم التسليم، ملغي)
- `prepared_by`, `delivered_by`: تتبع من قام بالإعداد والتسليم

---

#### 2. جدول `production_batches` (دفعات الإنتاج)
```sql
CREATE TABLE production_batches (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    batch_number VARCHAR(50) UNIQUE NOT NULL, -- رقم فريد للدفعة
    coil_number VARCHAR(100), -- رقم الكويلة الخام
    coil_original_weight DECIMAL(10,2), -- الوزن الأصلي للكويلة
    source_material_id BIGINT UNSIGNED NOT NULL, -- المادة الخام
    target_material_id BIGINT UNSIGNED, -- المنتج النهائي
    production_stage_id BIGINT UNSIGNED, -- المرحلة الإنتاجية
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    status ENUM('planned', 'in_progress', 'completed', 'cancelled') DEFAULT 'planned',
    total_input_weight DECIMAL(10,2), -- الوزن الداخل
    total_output_weight DECIMAL(10,2), -- الوزن الخارج
    waste_weight DECIMAL(10,2), -- وزن الهالك
    waste_percentage DECIMAL(5,2), -- نسبة الهالك الفعلية
    standard_waste_percentage DECIMAL(5,2), -- النسبة القياسية
    variance DECIMAL(5,2), -- الانحراف
    created_by BIGINT UNSIGNED,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (source_material_id) REFERENCES materials(id),
    FOREIGN KEY (target_material_id) REFERENCES materials(id),
    FOREIGN KEY (production_stage_id) REFERENCES production_stages(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    
    INDEX idx_batch_number (batch_number),
    INDEX idx_coil_number (coil_number),
    INDEX idx_status (status),
    INDEX idx_date (started_at)
);
```

**ملاحظات التصميم:**
- `coil_number`: ربط المنتجات بالكويلة المستخدمة (حسب الاجتماع)
- `waste_percentage` و `standard_waste_percentage`: لمقارنة الهالك الفعلي بالمعياري
- `variance`: الانحراف = الهالك الفعلي - الهالك المعياري

---

#### 3. جدول `batch_products` (منتجات الدفعة)
```sql
CREATE TABLE batch_products (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    batch_id BIGINT UNSIGNED NOT NULL,
    material_id BIGINT UNSIGNED NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    weight DECIMAL(10,2) NOT NULL,
    unit_cost DECIMAL(10,2), -- تكلفة الوحدة
    total_cost DECIMAL(12,2), -- التكلفة الإجمالية
    warehouse_id BIGINT UNSIGNED, -- المخزن الذي دخل إليه
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (batch_id) REFERENCES production_batches(id) ON DELETE CASCADE,
    FOREIGN KEY (material_id) REFERENCES materials(id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(id),
    
    INDEX idx_batch (batch_id),
    INDEX idx_material (material_id)
);
```

**الغرض:** تفصيل المنتجات الناتجة من كل دفعة إنتاج

---

#### 4. جدول `warehouse_transfers` (نقل المخزون)
```sql
CREATE TABLE warehouse_transfers (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    transfer_number VARCHAR(50) UNIQUE NOT NULL,
    from_warehouse_id BIGINT UNSIGNED NOT NULL,
    to_warehouse_id BIGINT UNSIGNED NOT NULL,
    material_id BIGINT UNSIGNED NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    transfer_type ENUM('production', 'adjustment', 'return') DEFAULT 'production',
    status ENUM('pending', 'approved', 'completed', 'cancelled') DEFAULT 'pending',
    requested_by BIGINT UNSIGNED,
    approved_by BIGINT UNSIGNED,
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_at TIMESTAMP,
    completed_at TIMESTAMP,
    notes TEXT,
    
    FOREIGN KEY (from_warehouse_id) REFERENCES warehouses(id),
    FOREIGN KEY (to_warehouse_id) REFERENCES warehouses(id),
    FOREIGN KEY (material_id) REFERENCES materials(id),
    FOREIGN KEY (requested_by) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id),
    
    INDEX idx_transfer_number (transfer_number),
    INDEX idx_status (status)
);
```

---

#### 5. جدول `inventory_audits` (جرد المخزون)
```sql
CREATE TABLE inventory_audits (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    audit_number VARCHAR(50) UNIQUE NOT NULL,
    warehouse_id BIGINT UNSIGNED NOT NULL,
    audit_date DATE NOT NULL,
    status ENUM('in_progress', 'completed', 'approved') DEFAULT 'in_progress',
    conducted_by BIGINT UNSIGNED,
    approved_by BIGINT UNSIGNED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_at TIMESTAMP,
    
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(id),
    FOREIGN KEY (conducted_by) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id),
    
    INDEX idx_warehouse (warehouse_id),
    INDEX idx_date (audit_date)
);

CREATE TABLE inventory_audit_items (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    audit_id BIGINT UNSIGNED NOT NULL,
    material_id BIGINT UNSIGNED NOT NULL,
    system_quantity DECIMAL(10,2) NOT NULL, -- الكمية في النظام
    actual_quantity DECIMAL(10,2) NOT NULL, -- الكمية الفعلية
    variance DECIMAL(10,2) AS (actual_quantity - system_quantity), -- الفرق
    variance_reason ENUM('waste', 'theft', 'data_error', 'other'),
    notes TEXT,
    
    FOREIGN KEY (audit_id) REFERENCES inventory_audits(id) ON DELETE CASCADE,
    FOREIGN KEY (material_id) REFERENCES materials(id),
    
    INDEX idx_audit (audit_id)
);
```

---

### التعديلات على الجداول الموجودة

#### تعديل جدول `material_batches`
```sql
ALTER TABLE material_batches
ADD COLUMN coil_number VARCHAR(100) AFTER batch_number,
ADD COLUMN coil_original_weight DECIMAL(10,2) AFTER coil_number,
ADD COLUMN production_batch_id BIGINT UNSIGNED AFTER id,
ADD FOREIGN KEY (production_batch_id) REFERENCES production_batches(id),
ADD INDEX idx_coil_number (coil_number);
```

#### تعديل جدول `production_stages`
```sql
ALTER TABLE production_stages
ADD COLUMN standard_waste_percentage DECIMAL(5,2) DEFAULT 0 AFTER stage_name,
ADD COLUMN max_waste_percentage DECIMAL(5,2) DEFAULT 0 AFTER standard_waste_percentage;
```

**البيانات المرجعية:**
```sql
UPDATE production_stages SET standard_waste_percentage = 6, max_waste_percentage = 7 WHERE stage_name = 'سحب';
UPDATE production_stages SET standard_waste_percentage = 4, max_waste_percentage = 5 WHERE stage_name = 'جلفنة';
UPDATE production_stages SET standard_waste_percentage = 2.5, max_waste_percentage = 3 WHERE stage_name = 'تشكيل';
UPDATE production_stages SET standard_waste_percentage = 1.5, max_waste_percentage = 2 WHERE stage_name = 'قص';
```

---

## 🔄 العمليات (Business Processes)

### Process 1: إنشاء إذن صرف للعميل

**الخطوات:**
1. المستخدم ينشئ إذن صرف جديد
2. يدخل بيانات العميل (الاسم، الهاتف، العنوان)
3. يختار المنتج من المخزن
4. يدخل الكمية المطلوبة
5. النظام يتحقق من توفر الكمية
6. النظام يحسب التكلفة الإجمالية
7. المستخدم يحفظ الإذن بحالة "مسودة"
8. عند الجاهزية، يغير الحالة إلى "جاهز للتسليم"
9. عند التسليم الفعلي:
   - تسجيل من قام بالتسليم
   - تسجيل تاريخ ووقت التسليم
   - خصم الكمية من المخزن تلقائياً
   - تغيير الحالة إلى "تم التسليم"

**الكود المقترح (Controller):**
```php
public function store(Request $request)
{
    $validated = $request->validate([
        'customer_name' => 'required|string|max:255',
        'customer_phone' => 'nullable|string|max:50',
        'customer_address' => 'nullable|string',
        'material_id' => 'required|exists:materials,id',
        'warehouse_id' => 'required|exists:warehouses,id',
        'quantity' => 'required|numeric|min:0',
    ]);

    // التحقق من توفر الكمية
    $available = MaterialDetail::where('material_id', $validated['material_id'])
        ->where('warehouse_id', $validated['warehouse_id'])
        ->sum('quantity');

    if ($available < $validated['quantity']) {
        return back()->withErrors(['quantity' => 'الكمية المطلوبة غير متوفرة في المخزن']);
    }

    // إنشاء رقم إذن الصرف
    $year = now()->year;
    $lastNumber = DeliveryNote::whereYear('created_at', $year)
        ->max(DB::raw('CAST(SUBSTRING(delivery_note_number, -3) AS UNSIGNED)'));
    $nextNumber = str_pad(($lastNumber ?? 0) + 1, 3, '0', STR_PAD_LEFT);
    $deliveryNoteNumber = "{$year}-{$nextNumber}";

    $deliveryNote = DeliveryNote::create([
        'delivery_note_number' => $deliveryNoteNumber,
        'customer_name' => $validated['customer_name'],
        'customer_phone' => $validated['customer_phone'],
        'customer_address' => $validated['customer_address'],
        'material_id' => $validated['material_id'],
        'warehouse_id' => $validated['warehouse_id'],
        'quantity' => $validated['quantity'],
        'status' => 'draft',
        'prepared_by' => auth()->id(),
        'prepared_at' => now(),
    ]);

    return redirect()->route('delivery-notes.show', $deliveryNote)
        ->with('success', 'تم إنشاء إذن الصرف بنجاح');
}

public function deliver(DeliveryNote $deliveryNote)
{
    if ($deliveryNote->status !== 'ready') {
        return back()->withErrors(['status' => 'لا يمكن تسليم إذن صرف غير جاهز']);
    }

    DB::transaction(function () use ($deliveryNote) {
        // خصم الكمية من المخزن
        $this->deductFromWarehouse(
            $deliveryNote->material_id,
            $deliveryNote->warehouse_id,
            $deliveryNote->quantity
        );

        // تحديث حالة الإذن
        $deliveryNote->update([
            'status' => 'delivered',
            'delivered_by' => auth()->id(),
            'delivered_at' => now(),
        ]);
    });

    return redirect()->route('delivery-notes.index')
        ->with('success', 'تم تسليم الإذن وخصم الكمية من المخزن');
}
```

---

### Process 2: بدء دفعة إنتاج جديدة

**الخطوات:**
1. مدير الإنتاج يبدأ دفعة جديدة
2. يختار الكويلة الخام من المخزن
3. يدخل رقم الكويلة ووزنها الأصلي
4. يختار المرحلة الإنتاجية
5. يدخل المنتج المستهدف
6. النظام ينشئ سجل دفعة إنتاج
7. أثناء الإنتاج:
   - تسجيل الوزن الداخل والخارج لكل مرحلة
   - حساب نسبة الهالك تلقائياً
   - مقارنة بالنسبة القياسية
   - تنبيه إذا تجاوزت الحد المسموح
8. عند الانتهاء:
   - تسجيل المنتجات النهائية
   - إضافتها للمخزن المناسب
   - حساب التكلفة الإجمالية
   - إغلاق الدفعة

**مثال من الاجتماع:**
- كويلة 2005: 29,500 كجم
- أنتجت: سلك شوك 14 ملم
- الكمية: 1,850 كجم
- المرحلة: سحب
- الهالك المتوقع: 5-7%

---

## 📊 المعادلات الحسابية

### 1. حساب نسبة الهالك
```
نسبة الهالك = (الوزن الداخل - الوزن الخارج) / الوزن الداخل × 100
```

**مثال:**
```
وزن داخل = 1000 كجم
وزن خارج = 950 كجم
نسبة الهالك = (1000 - 950) / 1000 × 100 = 5%
```

### 2. حساب الانحراف
```
الانحراف = نسبة الهالك الفعلية - النسبة القياسية
```

**مثال:**
```
هالك فعلي = 7.5%
هالك معياري = 6%
الانحراف = 7.5% - 6% = +1.5% (غير مقبول)
```

### 3. حساب تكلفة الإنتاج
```
تكلفة المادة الخام = وزن الكويلة × سعر الكيلو
تكلفة الهالك = (الوزن الداخل - الوزن الخارج) × سعر الكيلو
التكلفة الإجمالية = تكلفة المادة الخام + تكلفة الهالك + تكاليف التشغيل
تكلفة الوحدة = التكلفة الإجمالية / عدد الوحدات المنتجة
```

---

## 🚀 خطة التنفيذ (Implementation Plan)

### المرحلة 1: البنية التحتية (أسبوع 1-2)
- [ ] إنشاء migrations للجداول الجديدة
- [ ] إنشاء Models بالعلاقات
- [ ] إنشاء Seeders للبيانات المرجعية
- [ ] تعديل الجداول الموجودة

### المرحلة 2: نظام إذن الصرف (أسبوع 3-4)
- [ ] صفحة قائمة إذونات الصرف
- [ ] صفحة إنشاء إذن جديد
- [ ] صفحة عرض تفاصيل الإذن
- [ ] نظام تغيير الحالات
- [ ] طباعة الإذن (PDF)
- [ ] خصم المخزون عند التسليم

### المرحلة 3: تتبع دفعات الإنتاج (أسبوع 5-6)
- [ ] صفحة قائمة الدفعات
- [ ] صفحة إنشاء دفعة جديدة
- [ ] ربط الكويلة بالدفعة
- [ ] تسجيل الأوزان والهالك
- [ ] حساب النسب تلقائياً
- [ ] التنبيهات عند تجاوز الحدود

### المرحلة 4: إدارة المخزون (أسبوع 7-8)
- [ ] نظام نقل المخزون بين المخازن
- [ ] نظام الجرد الدوري
- [ ] معالجة الفروقات
- [ ] سجل الحركات الكامل

### المرحلة 5: التقارير (أسبوع 9-10)
- [ ] تقرير تكلفة الإنتاج
- [ ] تقرير حركة المخزون
- [ ] تقرير نسب الهالك
- [ ] تقرير إذونات الصرف
- [ ] تصدير التقارير (PDF/Excel)

### المرحلة 6: الاختبار والتدريب (أسبوع 11-12)
- [ ] اختبار جميع الوظائف
- [ ] إصلاح الأخطاء
- [ ] تدريب المستخدمين
- [ ] إعداد دليل المستخدم

---

## 🎨 واجهات المستخدم المقترحة

### 1. صفحة قائمة إذونات الصرف
```
┌─────────────────────────────────────────────────────────────┐
│  📋 إذونات الصرف                          [+ إذن جديد]    │
├─────────────────────────────────────────────────────────────┤
│  🔍 بحث: [___________]  التاريخ: [من__] [إلى__]  [بحث]   │
│  الحالة: [الكل ▼]  العميل: [الكل ▼]                      │
├─────────────────────────────────────────────────────────────┤
│ رقم الإذن │ التاريخ    │ العميل      │ المنتج    │ الحالة │
├──────────┼──────────┼───────────┼─────────┼────────┤
│ 2025-019 │ 22/11/25 │ شركة XYZ   │ سلك 14  │ 🟢 تم  │
│ 2025-018 │ 21/11/25 │ محمد أحمد │ حديد 12 │ 🟡 جاهز│
│ 2025-017 │ 20/11/25 │ علي خالد  │ سلك 10  │ 🔵 مسودة│
└──────────┴──────────┴───────────┴─────────┴────────┘
```

### 2. صفحة إنشاء إذن صرف
```
┌─────────────────────────────────────────────────────────────┐
│  📝 إنشاء إذن صرف جديد                                     │
├─────────────────────────────────────────────────────────────┤
│  📋 بيانات العميل                                          │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ اسم العميل: [_________________________________]     │   │
│  │ رقم الهاتف: [_________________________________]     │   │
│  │ العنوان:    [_________________________________]     │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  📦 بيانات المنتج                                          │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ المخزن:  [اختر المخزن ▼]                           │   │
│  │ المنتج:  [اختر المنتج ▼]                           │   │
│  │ المتاح:  1,850 كجم                                  │   │
│  │ الكمية:  [_______] كجم                              │   │
│  │ السعر:   25 جنيه/كجم                                │   │
│  │ الإجمالي: 0.00 جنيه                                 │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  💬 ملاحظات                                                │
│  [_____________________________________________________]   │
│  [_____________________________________________________]   │
│                                                             │
│  [💾 حفظ مسودة]  [✅ حفظ وجاهز للتسليم]  [❌ إلغاء]     │
└─────────────────────────────────────────────────────────────┘
```

### 3. صفحة تفاصيل الدفعة الإنتاجية
```
┌───────────────────────────────────────────────────���─────────┐
│  🏭 دفعة إنتاج #BATCH-2025-045                             │
│  الحالة: 🟢 مكتملة                                         │
├─────────────────────────────────────────────────────────────┤
│  📊 معلومات الكويلة                                        │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ رقم الكويلة:       2005                             │   │
│  │ الوزن الأصلي:      29,500 كجم                       │   │
│  │ المستخدم:          1,850 كجم                        │   │
│  │ المتبقي:           27,650 كجم                       │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ⚙️ مراحل الإنتاج                                          │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ المرحلة    │ داخل   │ خارج  │ هالك │ النسبة │ الحالة│   │
│  ├──────────┼──────┼──────┼─────┼──────┼──────┤   │
│  │ السحب     │ 1850  │ 1750 │ 100  │ 5.4%  │ ✅   │   │
│  │ الجلفنة   │ 1750  │ 1680 │  70  │ 4.0%  │ ✅   │   │
│  │ التشكيل   │ 1680  │ 1640 │  40  │ 2.4%  │ ✅   │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  💰 التكلفة                                                 │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ تكلفة المواد الخام:  46,250 جنيه                   │   │
│  │ تكلفة الهالك:        5,250 جنيه                    │   │
│  │ تكاليف التشغيل:      8,500 جنيه                    │   │
│  │ ──────────────────────────────                      │   │
│  │ الإجمالي:            60,000 جنيه                   │   │
│  │ تكلفة الكيلو:        36.59 جنيه                    │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  [📄 طباعة التقرير]  [📊 عرض التفاصيل]                    │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔐 الصلاحيات (Permissions)

### صلاحيات إذونات الصرف
- `delivery_notes.view` - عرض قائمة الإذونات
- `delivery_notes.create` - إنشاء إذن جديد
- `delivery_notes.edit` - تعديل إذن مسودة
- `delivery_notes.deliver` - تسليم الإذن (خصم من المخزون)
- `delivery_notes.cancel` - إلغاء الإذن
- `delivery_notes.print` - طباعة الإذن

### صلاحيات دفعات الإنتاج
- `production_batches.view` - عرض الدفعات
- `production_batches.create` - إنشاء دفعة جديدة
- `production_batches.edit` - تعديل دفعة
- `production_batches.close` - إغلاق دفعة
- `production_batches.costs` - عرض التكاليف التفصيلية

### صلاحيات المخزون
- `inventory.transfer` - نقل المخزون
- `inventory.audit` - إجراء الجرد
- `inventory.approve_audit` - اعتماد الجرد
- `inventory.adjust` - تعديل الكميات

---

## 📝 ملاحظات من الاجتماع

### النقاط المهمة المذكورة:

1. **نظام الترقيم:**
   - إذن الصرف: YYYY-XXX (مثال: 2025-019)
   - رقم الكويلة يتم تسجيله يدوياً من قبل المستخدم

2. **نسب الهالك:**
   - يجب مقارنتها بالنسب القياسية
   - تنبيه عند التجاوز
   - تسجيل الأسباب في حالة الانحراف

3. **حساب التكلفة:**
   - تشمل: المواد الخام + الهالك + التشغيل
   - يتم حسابها لكل دفعة
   - ربطها بالكويلة المستخدمة

4. **المخازن:**
   - مخزن المواد الخام
   - مخزن تحت التشغيل (لكل مرحلة)
   - مخزن المنتجات النهائية
   - يجب تتبع الحركة بينها

5. **التقارير المطلوبة:**
   - تقرير يومي بإذونات الصرف
   - تقرير بتكلفة الإنتاج لكل دفعة
   - تقرير بنسب الهالك والانحرافات
   - تقرير حركة المخزون

---

## ⚠️ نقاط تحتاج توضيح

1. **السعر في إذن الصرف:**
   - هل يتم إدخاله يدوياً أم مرتبط بجدول أسعار؟
   - هل يتغير السعر حسب العميل أو الكمية؟

2. **الدفعات الجزئية:**
   - هل يمكن استخدام كويلة واحدة لعدة دفعات؟
   - كيف يتم تتبع الوزن المتبقي من الكويلة؟

3. **المرتجعات:**
   - هل يوجد نظام مرتجعات من العملاء؟
   - كيف يتم إعادة المنتج للمخزون؟

4. **الجرد:**
   - كم مرة يتم في السنة؟
   - من يعتمد الجرد؟

---

## 🎯 المخرجات المتوقعة (Deliverables)

### 1. كود البرنامج
- ✅ Migrations كاملة
- ✅ Models مع العلاقات
- ✅ Controllers مع Business Logic
- ✅ Requests للـ Validation
- ✅ Views (Blade Templates)
- ✅ Routes

### 2. التوثيق
- ✅ دليل المستخدم (User Manual)
- ✅ دليل المطور (Technical Documentation)
- ✅ API Documentation (إذا لزم)

### 3. البيانات
- ✅ Seeders للبيانات المرجعية
- ✅ بيانات تجريبية للاختبار

### 4. التقارير
- ✅ Templates للتقارير
- ✅ Export لـ PDF و Excel

---

## 📚 المراجع التقنية

### Laravel Best Practices
- استخدام Database Transactions للعمليات الحرجة
- استخدام Events/Listeners لتتبع التغييرات
- استخدام Policies للصلاحيات
- استخدام Observers لتحديث الحقول المحسوبة

### مثال على Transaction:
```php
DB::transaction(function () use ($deliveryNote) {
    // خصم المخزون
    $this->deductFromWarehouse(...);
    
    // تحديث الإذن
    $deliveryNote->update([...]);
    
    // تسجيل في الـ Log
    ActivityLog::create([...]);
});
```

---

## ✅ Checklist للتنفيذ

### قاعدة البيانات
- [ ] إنشاء migration: delivery_notes
- [ ] إنشاء migration: production_batches
- [ ] إنشاء migration: batch_products
- [ ] إنشاء migration: warehouse_transfers
- [ ] إنشاء migration: inventory_audits
- [ ] تعديل material_batches (add coil_number)
- [ ] تعديل production_stages (add waste percentages)
- [ ] Seeder: نسب الهالك القياسية

### Models
- [ ] DeliveryNote Model
- [ ] ProductionBatch Model
- [ ] BatchProduct Model
- [ ] WarehouseTransfer Model
- [ ] InventoryAudit Model

### Controllers
- [ ] DeliveryNoteController
- [ ] ProductionBatchController
- [ ] WarehouseTransferController
- [ ] InventoryAuditController

### Views
- [ ] delivery_notes/index
- [ ] delivery_notes/create
- [ ] delivery_notes/show
- [ ] production_batches/index
- [ ] production_batches/create
- [ ] production_batches/show

### Reports
- [ ] تقرير إذونات الصرف
- [ ] تقرير تكلفة الإنتاج
- [ ] تقرير نسب الهالك
- [ ] تقرير حركة المخزون

---

## 🎓 خلاصة

هذا المستند يوفر خارطة طريق كاملة لتطوير:
1. **نظام إذن الصرف والتسليم** للعملاء
2. **نظام تتبع دفعات الإنتاج** مع ربط الكويلات
3. **حساب نسب الهالك** ومقارنتها بالمعايير
4. **إدارة حركة المخزون** بين المراحل
5. **التقارير التحليلية** للتكاليف والهالك

---

**آخر تحديث:** 25 نوفمبر 2025  
**معد بواسطة:** GitHub Copilot  
**بناءً على:** محضر الاجتماع الثالث - 22 نوفمبر 2025
