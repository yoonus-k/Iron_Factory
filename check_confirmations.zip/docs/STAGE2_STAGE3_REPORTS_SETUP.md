# تقارير إدارة المرحلة الثانية والثالثة

## نظرة عامة

تم إنشاء تقارير إدارية شاملة للمرحلة الثانية (المعالجة) والمرحلة الثالثة (التلوين والتغليف) بنفس أسلوب وميزات التقرير الأول.

## الملفات المنشأة

### 1. متحكمات (Controllers)

#### Stage2ManagementReportController.php
**المسار:** `Modules/Manufacturing/Http/Controllers/Stage2ManagementReportController.php`

**الميزات:**
- عرض تقرير شامل لعمليات المعالجة
- جلب البيانات من جدول `stage2_processed`
- الربط مع `stage1_stands` لمعرفة الاستاند الأصلي
- دعم الفلاتر:
  - البحث بالباركود أو الباركود الأب
  - التصفية بالحالة (started, in_progress, completed, consumed)
  - التصفية بالعامل
  - التصفية بالتاريخ (من وإلى)
  - التصفية بنسبة الهدر (safe, warning, critical)
  - الترتيب والفرز

**المتغيرات المتاحة:**
- `totalProcessed` - إجمالي العمليات
- `processedToday` - اليوم فقط
- `completedProcessing` - العمليات المكتملة
- `completionRate` - معدل الإتمام
- `totalInputWeight` - الوزن الداخل
- `totalOutputWeight` - الوزن الناتج
- `totalWaste` - الهدر الكلي
- `avgWastePercentage` - متوسط نسبة الهدر
- وغيرها...

#### Stage3ManagementReportController.php
**المسار:** `Modules/Manufacturing/Http/Controllers/Stage3ManagementReportController.php`

**الميزات:**
- عرض تقرير شامل لعمليات التلوين والتغليف
- جلب البيانات من جدول `stage3_coils`
- دعم نفس الفلاتر والفرز
- تتبع الأوزان المختلفة (base_weight, dye_weight, plastic_weight, total_weight)
- دعم حالات التقدم (created, in_process, completed, packed)

### 2. الـ Views (النماذج)

#### stage2_management_report.blade.php
**المسار:** `Modules/Manufacturing/resources/views/reports/stage2_management_report.blade.php`

**المحتوى:**
- رأس التقرير مع معلومات المرحلة الثانية
- 11 بطاقة KPI (مؤشرات الأداء الرئيسية)
- أقسام التنبيهات والتحذيرات
- نموذج البحث والتصفية المتقدم
- جدول السجلات الكاملة
- جدول العمليات اليومية
- جدول تراكم البيانات من اليوم الأول
- قسم إحصائيات التفاصيل
- قسم توزيع الحالات
- أفضل العاملين
- جدول آخر 10 سجلات
- تحليل الهدر

#### stage3_management_report.blade.php
**المسار:** `Modules/Manufacturing/resources/views/reports/stage3_management_report.blade.php`

نفس البنية مع تحديثات خاصة بالمرحلة الثالثة والملفات.

### 3. الروابط (Routes)

تم إضافة روابط جديدة في `routes/web.php`:

```php
// تقرير المرحلة الثانية
Route::get('reports/stage2-management', [Stage2ManagementReportController::class, 'index'])
    ->middleware('permission:STAGE2_PROCESSED_READ')
    ->name('manufacturing.reports.stage2-management');

// تقرير المرحلة الثالثة
Route::get('reports/stage3-management', [Stage3ManagementReportController::class, 'index'])
    ->middleware('permission:STAGE3_COILS_READ')
    ->name('manufacturing.reports.stage3-management');
```

### 4. القائمة الجانبية (Sidebar)

تم إضافة عناصر قائمة جديدة في `resources/views/layout/sidebar.blade.php`:

```blade
@if(auth()->user()->hasPermission('STAGE2_PROCESSED_READ'))
<li>
    <a href="{{ route('manufacturing.reports.stage2-management') }}">
        <i class="fas fa-cogs"></i> ⚙️ تقرير المرحلة الثانية
    </a>
</li>
@endif

@if(auth()->user()->hasPermission('STAGE3_COILS_READ'))
<li>
    <a href="{{ route('manufacturing.reports.stage3-management') }}">
        <i class="fas fa-palette"></i> 🎨 تقرير المرحلة الثالثة
    </a>
</li>
@endif
```

## الوصول إلى التقارير

### روابط الوصول المباشر:
- **المرحلة الثانية:** `/manufacturing/reports/stage2-management`
- **المرحلة الثالثة:** `/manufacturing/reports/stage3-management`

### من خلال القائمة الجانبية:
1. اذهب إلى **التقارير** (Reports)
2. انقر على **⚙️ تقرير المرحلة الثانية** أو **🎨 تقرير المرحلة الثالثة**

## الصلاحيات المطلوبة

- **للمرحلة الثانية:** `STAGE2_PROCESSED_READ`
- **للمرحلة الثالثة:** `STAGE3_COILS_READ`

تأكد من تعيين هذه الصلاحيات للمستخدمين الذين يريدون الوصول للتقارير.

## المميزات الأساسية

### 1. لوحة KPI (مؤشرات الأداء)
- إجمالي العمليات/الملفات
- العمليات اليومية
- معدل الإتمام
- الأوزان الداخلة والخارجة والهدر
- نسب الهدر (أعلى وأقل)
- عدد العمال النشطين
- متوسط الأداء اليومي
- معدل الالتزام بالجودة

### 2. البحث والتصفية المتقدمة
- البحث الحر بالباركود
- التصفية بالحالة
- التصفية بالعامل
- التصفية بنطاق التاريخ
- التصفية بنسبة الهدر (آمن/تحذير/حرج)
- الترتيب حسب أي حقل
- اتجاه الترتيب (تصاعدي/تنازلي)

### 3. الجداول المتقدمة
- جدول السجلات الكاملة مع كل البيانات
- جدول العمليات اليومية
- جدول تراكم البيانات
- جدول آخر 10 سجلات

### 4. الألوان والرموز
- رموز الحالة مع ألوان مختلفة
- مؤشرات نسبة الهدر:
  - أخضر: الهدر المقبول (<= 8%)
  - أصفر: التحذيري (8% - 15%)
  - أحمر: الحرج (> 15%)

### 5. الإحصائيات والتحليل
- توزيع الحالات
- أداء العاملين
- معدل الكفاءة
- تحليل الهدر المفصل

## ملاحظات تقنية

1. **الأداء:**
   - يتم جلب جميع البيانات ثم معالجتها في الـ Collection
   - يمكن تحسينها بإضافة Pagination للجداول الكبيرة

2. **التواريخ:**
   - يتم التعامل مع تواريخ String و Carbon objects بشكل آمن
   - استخدام `is_string()` للتحقق من نوع البيانات

3. **الصلاحيات:**
   - جميع المسارات محمية بـ middleware للصلاحيات
   - يتم التحقق من الصلاحيات في بداية كل متحكم

4. **الاستجابة:**
   - التقارير مُحسّنة للعرض على الأجهزة المختلفة
   - الطباعة محسّنة مع CSS مخصص

## التطوير المستقبلي

### المميزات المخطط لها:
- [ ] تصدير PDF
- [ ] تصدير Excel
- [ ] رسوم بيانية تفاعلية
- [ ] مقارنة الفترات الزمنية
- [ ] إشعارات الأداء المنخفض
- [ ] تقارير مخصصة
- [ ] جدولة التقارير
- [ ] إرسال التقارير بالبريد

## استكشاف الأخطاء

### المشكلة: التقرير لا يفتح
**الحل:**
1. تحقق من وجود صلاحية `STAGE2_PROCESSED_READ` أو `STAGE3_COILS_READ`
2. تحقق من تسجيل الدخول
3. تحقق من وجود البيانات في قاعدة البيانات

### المشكلة: الفلاتر لا تعمل
**الحل:**
1. تأكد من إدخال بيانات صحيحة في حقول الفلتر
2. حاول إعادة تحديث الصفحة
3. تحقق من أن الباركود أو التاريخ صحيح

### المشكلة: الأرقام غير دقيقة
**الحل:**
1. تحقق من بيانات الوزن في جدول قاعدة البيانات
2. تأكد من عدم وجود قيم فارغة أو أصفار
3. تحقق من صيغة الحساب

## الدعم والمساعدة

للإبلاغ عن مشاكل أو طلب ميزات جديدة، يرجى الاتصال بـ:
- **فريق التطوير:** development@ironfactory.local
- **دعم المستخدمين:** support@ironfactory.local

---
**آخر تحديث:** ديسمبر 2025
