# خطة تطبيق نظام المنتجات النهائية والإذونات الصادرة
**تاريخ:** 27 نوفمبر 2025

---

## ✅ ملخص القرارات بناءً على البنية الحالية

### 🎯 الإجابات على الأسئلة:
1. ✅ **نوع المنتج:** تلقائي من المرحلة 4 (packaging_type من stage4_boxes)
2. ✅ **رقم الباتش (الباركود):** كل كرتونة لها باركود `BOX4-XXX-2025`
3. ✅ **الكميات الجزئية:** مسموحة (يمكن شحن كراتين محددة من مجموعة)
4. ✅ **بيانات العملاء:** غير موجودة، سننشئ جدول `customers`
5. ✅ **الصلاحيات:** مدير عام + مشرف الوردية + مدير إنتاج

### 🔄 استخدام الجداول الموجودة:
```
✅ delivery_notes       → سنوسعه للإذونات الصادرة
✅ stage4_boxes         → المنتجات النهائية (الكراتين)
✅ product_tracking     → تتبع حركة المنتج
🆕 customers            → جدول جديد للعملاء
```

---

## 📊 الهيكلية النهائية

### **1. تعديل `delivery_notes`**

**الحقول الجديدة:**
```php
Schema::table('delivery_notes', function (Blueprint $table) {
    // نوع الإذن
    $table->string('type', 50)->default('incoming')->after('note_number');
    // incoming: واردة للمستودع
    // outgoing: صادرة من المستودع (مواد خام)
    // finished_product_outgoing: صادرة للعميل (منتجات نهائية)
    
    // للإذونات الصادرة للعملاء
    $table->foreignId('customer_id')->nullable()->constrained()->after('material_id');
    
    // الحالة
    $table->string('status', 50)->default('completed')->after('customer_id');
    // pending: بانتظار الاعتماد
    // approved: معتمد (جاهز للشحن/الطباعة)
    // rejected: مرفوض
    // completed: مكتمل (للإذونات الواردة)
    // shipped: تم الشحن
    
    // الموافقة والاعتماد
    $table->foreignId('approved_by')->nullable()->constrained('users')->after('received_by');
    $table->timestamp('approved_at')->nullable()->after('approved_by');
    $table->text('rejection_reason')->nullable()->after('approved_at');
    
    // الطباعة
    $table->integer('print_count')->default(0)->after('rejection_reason');
    
    // المصدر (للمنتجات النهائية)
    $table->string('source_type', 50)->nullable()->after('print_count');
    // 'stage4_box' للمنتجات النهائية
    
    $table->unsignedBigInteger('source_id')->nullable()->after('source_type');
    // ID من stage4_boxes
    
    // ملاحظات إضافية
    $table->text('notes')->nullable()->after('source_id');
});
```

### **2. جدول `customers` (جديد)**

```php
Schema::create('customers', function (Blueprint $table) {
    $table->id();
    
    // الرمز التلقائي
    $table->string('customer_code', 20)->unique();
    // مثال: CUST-2025-0001
    
    // البيانات الأساسية
    $table->string('name', 200);
    $table->string('company_name', 200)->nullable();
    $table->string('phone', 20);
    $table->string('email', 100)->nullable();
    
    // العنوان
    $table->text('address')->nullable();
    $table->string('city', 100)->nullable();
    $table->string('country', 100)->default('السعودية');
    
    // بيانات ضريبية
    $table->string('tax_number', 50)->nullable();
    
    // الحالة
    $table->boolean('is_active')->default(true);
    
    // ملاحظات
    $table->text('notes')->nullable();
    
    // من أنشأه
    $table->foreignId('created_by')->constrained('users');
    
    $table->timestamps();
    $table->softDeletes();
    
    // الفهارس
    $table->index('customer_code');
    $table->index('name');
    $table->index('phone');
    $table->index('is_active');
});
```

### **3. جدول ربط `delivery_note_items` (جديد)**

لربط الإذن الصادر بالكراتين المحددة:

```php
Schema::create('delivery_note_items', function (Blueprint $table) {
    $table->id();
    
    // الإذن
    $table->foreignId('delivery_note_id')->constrained()->onDelete('cascade');
    
    // الكرتونة
    $table->foreignId('stage4_box_id')->constrained()->onDelete('cascade');
    
    // البيانات
    $table->string('barcode', 50);
    $table->string('packaging_type', 100);
    $table->decimal('weight', 10, 3);
    
    $table->timestamps();
    
    // الفهارس
    $table->index('delivery_note_id');
    $table->index('stage4_box_id');
    $table->index('barcode');
});
```

---

## 🔄 سير العمل المحدث

### **السيناريو الكامل:**

```
┌─────────────────────────────────────────────────────────────────┐
│ المرحلة 4: التعبئة (Stage 4 - Packaging)                       │
│ ✅ stage4_boxes.status = 'packed'                               │
│ ✅ الكراتين جاهزة بباركود: BOX4-001-2025, BOX4-002-2025...   │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ مشرف الوردية / مدير الإنتاج                                    │
│ (يذهب لصفحة: "إذونات صادرة - منتجات نهائية")                  │
│ Route: /manufacturing/delivery-notes/create                     │
│ Query: ?type=finished_product_outgoing                          │
│                                                                  │
│ 1. يختار نوع الإذن: "صادرة - منتجات نهائية"                   │
│ 2. يدخل بيانات الشحنة:                                         │
│    • رقم لوحة السيارة: ABC-1234 (required)                     │
│    • اسم السائق: محمد أحمد (required)                           │
│    • العميل: [اختياري] أو "سيتم تحديده لاحقاً"                │
│ 3. يختار الكراتين (Barcodes):                                  │
│    - يمسح الباركود أو يختار من القائمة                         │
│    - BOX4-001-2025 ✓                                            │
│    - BOX4-015-2025 ✓                                            │
│    - BOX4-023-2025 ✓                                            │
│    - ... الخ (يمكن اختيار عدة كراتين)                          │
│ 4. النظام يحسب:                                                │
│    • إجمالي عدد الكراتين: 15                                   │
│    • إجمالي الوزن: 1,250 كجم                                   │
│ 5. يحفظ → delivery_notes:                                      │
│    - type = 'finished_product_outgoing'                         │
│    - status = 'pending'                                         │
│    - note_number = OUT-FP-2025-0001 (auto)                      │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ إشعار (Notification) → المدير العام                            │
│ "إذن صادر جديد بانتظار الاعتماد - OUT-FP-2025-0001"          │
│ عدد الكراتين: 15 | الوزن: 1,250 كجم                            │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ المدير العام (APPROVE_FINISHED_PRODUCT_DELIVERY)              │
│ (صفحة: "إذونات بانتظار الاعتماد")                              │
│                                                                  │
│ 1. يراجع التفاصيل:                                             │
│    • الكراتين والأوزان                                          │
│    • رقم السيارة والسائق                                        │
│    • العميل (إذا محدد)                                          │
│                                                                  │
│ 2. يمكنه:                                                       │
│    أ) اختيار/تغيير العميل من قائمة العملاء                    │
│    ب) تعديل ملاحظات الشحنة                                     │
│                                                                  │
│ 3. يعتمد (Approve) أو يرفض (Reject):                           │
│    → ✅ اعتماد:                                                 │
│       - delivery_notes.status = 'approved'                      │
│       - delivery_notes.approved_by = {manager_id}               │
│       - delivery_notes.approved_at = now()                      │
│       - stage4_boxes.status = 'shipped' (للكراتين المحددة)    │
│       - product_tracking: تسجيل action='shipped'                │
│                                                                  │
│    → ❌ رفض:                                                    │
│       - delivery_notes.status = 'rejected'                      │
│       - delivery_notes.rejection_reason = "السبب..."            │
│       - إشعار → مشرف الوردية                                    │
└─────────────────────────────────────────────────────────────────┘
                              ↓
          ┌─────────────────────────────────┐
          │  تم الاعتماد؟                   │
          └─────────────────────────────────┘
                 │                │
        ✅ نعم   │                │ ❌ لا
                 ↓                ↓
     ┌──────────────────┐  ┌──────────────────┐
     │ الحالة: approved │  │ الحالة: rejected │
     │ يمكن الطباعة الآن│  │ يمكن التعديل      │
     └──────────────────┘  └──────────────────┘
              ↓
┌─────────────────────────────────────────────────────────────────┐
│ الطباعة (PRINT_DELIVERY_NOTE)                                  │
│ Route: /manufacturing/delivery-notes/{id}/print                 │
│                                                                  │
│ نموذج الطباعة يحتوي على:                                       │
│ ┌──────────────────────────────────────────────────────────────┐│
│ │ شعار الشركة              إذن صادر - منتجات نهائية          ││
│ │                          رقم: OUT-FP-2025-0001               ││
│ │                          التاريخ: 27/11/2025                 ││
│ ├──────────────────────────────────────────────────────────────┤│
│ │ بيانات العميل:                                              ││
│ │ الاسم: شركة الأمل للتجارة                                   ││
│ │ الهاتف: 0501234567                                           ││
│ │ العنوان: الرياض، حي النخيل                                  ││
│ ├──────────────────────────────────────────────────────────────┤│
│ │ بيانات الشحن:                                               ││
│ │ رقم السيارة: ABC-1234                                       ││
│ │ السائق: محمد أحمد                                            ││
│ ├──────────────────────────────────────────────────────────────┤│
│ │ الكراتين المشحونة:                                          ││
│ │ ┌────────────────┬────────────────┬─────────────┐            ││
│ │ │ الباركود       │ نوع التغليف    │ الوزن (كجم) │            ││
│ │ ├────────────────┼────────────────┼─────────────┤            ││
│ │ │ BOX4-001-2025  │ كرتون مقوى     │ 85.5        │            ││
│ │ │ BOX4-015-2025  │ كرتون مقوى     │ 82.3        │            ││
│ │ │ BOX4-023-2025  │ كرتون مقوى     │ 87.1        │            ││
│ │ │ ...            │ ...            │ ...         │            ││
│ │ └────────────────┴────────────────┴─────────────┘            ││
│ │ الإجمالي: 15 كرتونة | الوزن الكلي: 1,250 كجم               ││
│ ├──────────────────────────────────────────────────────────────┤│
│ │ ملاحظات: يُرجى التعامل بحذر                                 ││
│ ├──────────────────────────────────────────────────────────────┤│
│ │ التوقيعات:                                                   ││
│ │ المشرف: ______  المدير: ______  السائق: ______              ││
│ │ التاريخ: ______  التاريخ: ______  التاريخ: ______           ││
│ └──────────────────────────────────────────────────────────────┘│
│                                                                  │
│ • يُطبع على A4                                                 │
│ • print_count يُحدث +1                                         │
│ • يمكن إعادة الطباعة عند الحاجة                               │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ تسليم الإذن للسائق                                             │
│ • السائق يستلم الإذن المطبوع + الكراتين                       │
│ • delivery_notes.status = 'shipped' (اختياري)                  │
│ • stage4_boxes.status = 'shipped' (تم بالفعل)                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## ✅ خطة التطبيق النهائية

### **المرحلة 1: Database (التعديلات على قاعدة البيانات)**

#### **1.1 Migration: إنشاء جدول العملاء**
```bash
php artisan make:migration create_customers_table
```

#### **1.2 Migration: تعديل delivery_notes**
```bash
php artisan make:migration add_finished_product_fields_to_delivery_notes
```

#### **1.3 Migration: جدول ربط الإذن بالكراتين**
```bash
php artisan make:migration create_delivery_note_items_table
```

---

### **المرحلة 2: Models (النماذج)**

#### **2.1 إنشاء Customer Model**
```bash
php artisan make:model App/Models/Customer
```

**Relations:**
```php
- hasMany(DeliveryNote::class)
- belongsTo(User::class, 'created_by')
```

#### **2.2 تحديث DeliveryNote Model**

**إضافة Relations:**
```php
- belongsTo(Customer::class, 'customer_id')
- belongsTo(User::class, 'approved_by')
- hasMany(DeliveryNoteItem::class)
```

**إضافة Scopes:**
```php
- scopeFinishedProductOutgoing($query)
- scopePendingApproval($query)
- scopeApproved($query)
```

**إضافة Methods:**
```php
- approve(User $approver, ?int $customerId = null)
- reject(User $user, string $reason)
- canApprove(): bool
- canPrint(): bool
```

#### **2.3 إنشاء DeliveryNoteItem Model**
```bash
php artisan make:model App/Models/DeliveryNoteItem
```

**Relations:**
```php
- belongsTo(DeliveryNote::class)
- belongsTo(Stage4Box::class)
```

---

### **المرحلة 3: Permissions (الصلاحيات)**

#### **تحديث PermissionsSeeder:**

```php
// العملاء
['name' => 'MANAGE_CUSTOMERS', 'display_name' => 'إدارة العملاء', 'group_name' => 'العملاء'],
['name' => 'VIEW_CUSTOMERS', 'display_name' => 'عرض العملاء', 'group_name' => 'العملاء'],

// الإذونات الصادرة - منتجات نهائية
['name' => 'CREATE_FINISHED_PRODUCT_DELIVERY', 'display_name' => 'إنشاء إذن صادر - منتجات نهائية', 'group_name' => 'المنتجات النهائية'],
['name' => 'APPROVE_FINISHED_PRODUCT_DELIVERY', 'display_name' => 'اعتماد إذن صادر - منتجات نهائية', 'group_name' => 'المنتجات النهائية'],
['name' => 'REJECT_FINISHED_PRODUCT_DELIVERY', 'display_name' => 'رفض إذن صادر - منتجات نهائية', 'group_name' => 'المنتجات النهائية'],
['name' => 'PRINT_FINISHED_PRODUCT_DELIVERY', 'display_name' => 'طباعة إذن صادر - منتجات نهائية', 'group_name' => 'المنتجات النهائية'],
['name' => 'VIEW_FINISHED_PRODUCT_DELIVERIES', 'display_name' => 'عرض الإذونات الصادرة - منتجات نهائية', 'group_name' => 'المنتجات النهائية'],
```

---

### **المرحلة 4: Controllers**

#### **4.1 CustomerController**
```bash
php artisan make:controller CustomerController --resource
```

**Methods:**
- `index()` - قائمة العملاء
- `store()` - إضافة عميل
- `update()` - تعديل عميل
- `destroy()` - حذف (soft delete)
- `search()` - API للبحث (Ajax)

#### **4.2 FinishedProductDeliveryController**
```bash
php artisan make:controller Modules/Manufacturing/Http/Controllers/FinishedProductDeliveryController
```

**Methods:**
- `index()` - قائمة جميع الإذونات
- `create()` - صفحة إنشاء إذن جديد
- `store()` - حفظ الإذن (status=pending)
- `show($id)` - عرض تفاصيل الإذن
- `edit($id)` - تعديل (قبل الاعتماد فقط)
- `update($id)` - حفظ التعديلات
- `approve($id)` - اعتماد الإذن (للمدير)
- `reject($id)` - رفض الإذن
- `print($id)` - صفحة الطباعة
- `pendingApproval()` - الإذونات بانتظار الاعتماد
- `getAvailableBoxes()` - API - جلب الكراتين المتاحة

---

### **المرحلة 5: Routes**

```php
// في routes/web.php
Route::middleware(['auth'])->group(function () {
    // العملاء
    Route::resource('customers', CustomerController::class);
    Route::get('customers/search', [CustomerController::class, 'search'])->name('customers.search');
});

// في Modules/Manufacturing/routes/web.php
Route::prefix('manufacturing')->name('manufacturing.')->group(function () {
    // الإذونات الصادرة - منتجات نهائية
    Route::prefix('finished-product-deliveries')->name('finished-product-deliveries.')->group(function () {
        Route::get('/', [FinishedProductDeliveryController::class, 'index'])->name('index');
        Route::get('create', [FinishedProductDeliveryController::class, 'create'])->name('create');
        Route::post('/', [FinishedProductDeliveryController::class, 'store'])->name('store');
        Route::get('{id}', [FinishedProductDeliveryController::class, 'show'])->name('show');
        Route::get('{id}/edit', [FinishedProductDeliveryController::class, 'edit'])->name('edit');
        Route::put('{id}', [FinishedProductDeliveryController::class, 'update'])->name('update');
        
        // الإجراءات الخاصة
        Route::post('{id}/approve', [FinishedProductDeliveryController::class, 'approve'])->name('approve');
        Route::post('{id}/reject', [FinishedProductDeliveryController::class, 'reject'])->name('reject');
        Route::get('{id}/print', [FinishedProductDeliveryController::class, 'print'])->name('print');
        
        // الصفحات المفلترة
        Route::get('pending-approval', [FinishedProductDeliveryController::class, 'pendingApproval'])->name('pending-approval');
        
        // API
        Route::get('api/available-boxes', [FinishedProductDeliveryController::class, 'getAvailableBoxes'])->name('api.available-boxes');
    });
});
```

---

### **المرحلة 6: Views (الواجهات)**

#### **6.1 العملاء**
```
resources/views/customers/
├── index.blade.php
└── partials/
    └── customer-modal.blade.php
```

#### **6.2 الإذونات الصادرة - منتجات نهائية**
```
Modules/Manufacturing/resources/views/finished-product-deliveries/
├── index.blade.php              // القائمة الرئيسية مع Tabs
├── create.blade.php             // إنشاء إذن جديد
├── show.blade.php               // عرض التفاصيل + زر اعتماد/رفض
├── edit.blade.php               // تعديل (قبل الاعتماد)
├── pending-approval.blade.php   // للمدير - الإذونات المنتظرة
└── print.blade.php              // نموذج الطباعة
```

---

### **المرحلة 7: Sidebar & Navigation**

```blade
<!-- في sidebar.blade.php -->

<!-- العملاء -->
@if(auth()->user()->hasPermission('VIEW_CUSTOMERS'))
<li>
    <a href="{{ route('customers.index') }}">
        <i class="fas fa-users"></i>
        <span>العملاء</span>
    </a>
</li>
@endif

<!-- الإذونات الصادرة - منتجات نهائية -->
@if(auth()->user()->hasPermission('VIEW_FINISHED_PRODUCT_DELIVERIES'))
<li>
    <a href="{{ route('manufacturing.finished-product-deliveries.index') }}">
        <i class="fas fa-truck-loading"></i>
        <span>الإذونات الصادرة</span>
        @if($pendingCount = getPendingFinishedProductDeliveries())
            <span class="badge badge-warning">{{ $pendingCount }}</span>
        @endif
    </a>
</li>
@endif
```

---

### **المرحلة 8: Notifications**

```php
// إشعارات مطلوبة:
1. إذن صادر جديد → المدير العام
2. إذن معتمد → مشرف الوردية
3. إذن مرفوض → مشرف الوردية
```

---

## 🚀 ترتيب التنفيذ

### **الأولوية الأولى (اليوم 1):**
1. ✅ Migration: `create_customers_table`
2. ✅ Migration: `add_finished_product_fields_to_delivery_notes`
3. ✅ Migration: `create_delivery_note_items_table`
4. ✅ Model: `Customer`
5. ✅ تحديث Model: `DeliveryNote`
6. ✅ Model: `DeliveryNoteItem`
7. ✅ تحديث `PermissionsSeeder`
8. ✅ تشغيل Migrations و Seeder

### **الأولوية الثانية (اليوم 2):**
9. ✅ `CustomerController` + Routes
10. ✅ Views: `customers/index.blade.php` + modal
11. ✅ `FinishedProductDeliveryController` (البنية الأساسية)
12. ✅ Routes للإذونات الصادرة

### **الأولوية الثالثة (اليوم 3):**
13. ✅ View: `create.blade.php` (إنشاء إذن صادر)
14. ✅ View: `show.blade.php` (عرض التفاصيل)
15. ✅ View: `pending-approval.blade.php` (للمدير)
16. ✅ Approve & Reject Actions

### **الأولوية الرابعة (اليوم 4):**
17. ✅ View: `print.blade.php` (نموذج الطباعة)
18. ✅ View: `index.blade.php` (القائمة الرئيسية)
19. ✅ Sidebar Links
20. ✅ Notifications

### **الأولوية الخامسة (اليوم 5):**
21. ✅ Testing & Bug Fixes
22. ✅ تحسينات UI/UX
23. ✅ التوثيق النهائي

---

## 📝 ملاحظات مهمة

### **Security:**
- ✅ جميع الإجراءات محمية بالصلاحيات
- ✅ CSRF Protection
- ✅ Validation شامل
- ✅ Authorization checks

### **Performance:**
- ✅ Eager Loading للعلاقات
- ✅ Indexes على الأعمدة المهمة
- ✅ Pagination للقوائم
- ✅ Caching للإحصائيات

### **Data Integrity:**
- ✅ Foreign Keys
- ✅ Soft Deletes للعملاء
- ✅ Transaction wrapping للعمليات المهمة
- ✅ Validation قبل الحفظ

---

**الحالة:** جاهز للبدء ✅  
**التقدير الزمني:** 4-5 أيام عمل  
**آخر تحديث:** 27 نوفمبر 2025
