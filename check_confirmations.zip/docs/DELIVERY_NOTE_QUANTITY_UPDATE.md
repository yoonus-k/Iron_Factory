# 📦 تحديث الكمية عند الأذن الواردة (Incoming Delivery Notes)

## المشكلة الأصلية 🔴
الكمية المحفوظة في الأذن الواردة **ما كانت تنعكس على جدول MaterialDetail**. 

يعني عندما تسجل أذن واردة بـ 100 كيلو، الكمية ما تزيد في المستودع.

---

## الحل 🟢

### 1️⃣ عند إضافة أذن واردة جديدة (Store Method)

#### ✅ ما الذي يحدث الآن:

```php
// في DeliveryNoteController.php - store() method
if ($type === 'incoming') {
    // ... إعدادات الأذن ...
    
    // تحديث الكمية في MaterialDetail
    $materialDetail = \App\Models\MaterialDetail::firstOrCreate(
        [
            'warehouse_id' => $validated['warehouse_id'],
            'material_id' => $validated['material_id'],
        ]
    );
    
    // زيادة الكمية
    $quantityToAdd = $validated['invoice_weight'] ?? $validated['actual_weight'] ?? 0;
    $materialDetail->addIncomingQuantity($quantityToAdd, ...);
}
```

#### النتيجة:
✅ الكمية **تزيد تلقائياً** في جدول `material_details`  
✅ يتم إنشاء record جديد في `material_details` إذا لم يكن موجود  
✅ يتم تسجيل العملية في ملف السجلات (Log)

---

### 2️⃣ عند تعديل أذن واردة (Update Method)

#### ✅ ما الذي يحدث الآن:

```php
// في DeliveryNoteController.php - update() method
if ($type === 'incoming') {
    // حساب الفرق بين الكمية الجديدة والقديمة
    $oldQuantity = $oldValues['invoice_weight'] ?? 0;
    $newQuantity = $validated['invoice_weight'] ?? 0;
    $quantityDifference = $newQuantity - $oldQuantity;
    
    // تطبيق الفرق
    if ($quantityDifference > 0) {
        $materialDetail->addIncomingQuantity($quantityDifference, ...); // إضافة
    } else if ($quantityDifference < 0) {
        $materialDetail->quantity += $quantityDifference; // خصم
        $materialDetail->save();
    }
}
```

#### النتيجة:
✅ إذا **زادت الكمية** في التعديل → تزيد المادة  
✅ إذا **نقصت الكمية** في التعديل → تنقص المادة  
✅ الفرق يُطبق بدقة على الكمية الموجودة

---

### 3️⃣ عند حذف أذن واردة (Destroy Method)

#### ✅ ما الذي يحدث الآن:

```php
// في DeliveryNoteController.php - destroy() method
if ($deliveryNote->type === 'incoming') {
    // استرجاع الكمية من المستودع
    $materialDetail = \App\Models\MaterialDetail::where([
        'warehouse_id' => $deliveryNote->warehouse_id,
        'material_id' => $deliveryNote->material_id,
    ])->first();
    
    if ($materialDetail) {
        $quantityToRemove = $deliveryNote->invoice_weight ?? 0;
        $materialDetail->quantity -= $quantityToRemove;
        $materialDetail->save();
    }
}
```

#### النتيجة:
✅ عند حذف الأذن → **الكمية تنقص** من MaterialDetail  
✅ يعود المستودع إلى حالته الأصلية  
✅ يتم تسجيل العملية في السجلات

---

## المقارنة قبل وبعد 📊

| العملية | قبل التحديث ❌ | بعد التحديث ✅ |
|--------|-------------|------------|
| إضافة أذن واردة | الكمية ما تنعكس على MaterialDetail | الكمية تزيد تلقائياً |
| تعديل كمية الأذن | الفروقات ما تُحدّث | الفرق ينطبق بدقة |
| حذف أذن واردة | الكمية تبقى محتفظة به | الكمية تُسترجع للمستودع |
| إنشاء MaterialDetail | يجب إنشاء يدوي | ينشأ تلقائياً مع الأذن |

---

## مثال عملي 💡

### السيناريو:
1. المستودع حالياً: **0 كيلو** من المادة X
2. تسجيل أذن واردة: **100 كيلو** من المادة X

### قبل التحديث:
```
MaterialDetail quantity = 0 كيلو ❌
```

### بعد التحديث:
```
MaterialDetail quantity = 100 كيلو ✅
```

### السيناريو 2: التعديل
تعديل الأذن من 100 → 150 كيلو

### بعد التعديل:
```
MaterialDetail quantity = 150 كيلو ✅
(الفرق +50 تم إضافته)
```

### السيناريو 3: الحذف
حذف الأذن

### بعد الحذف:
```
MaterialDetail quantity = 0 كيلو ✅
(الكمية تم استرجاعها)
```

---

## الملفات المعدّلة 📝

### 1. DeliveryNoteController.php
- **store()**: إضافة تحديث الكمية للأذن الواردة الجديدة
- **update()**: إضافة حساب الفرق وتطبيقه
- **destroy()**: إضافة استرجاع الكمية عند الحذف

### 2. MaterialDetail.php (موجود مسبقاً)
- دالة `addIncomingQuantity()` - تزيد الكمية
- دالة `reduceOutgoingQuantity()` - تنقص الكمية

---

## ملاحظات مهمة ⚠️

1. **الكميات المستخدمة:**
   - للأذن الواردة: `invoice_weight` (الأولوية) أو `actual_weight`
   - للأذن الصادرة: `delivery_quantity` (يتم معالجتها بشكل منفصل)

2. **التسجيل:**
   - جميع العمليات تُسجل في ملف `storage/logs/laravel.log`
   - البحث عن "✅" أو "⚠️" للمراجعة

3. **معالجة الأخطاء:**
   - إذا فشل تحديث الكمية، العملية **لا تتوقف**
   - يتم تسجيل الخطأ فقط (لا نحذف الأذن)

4. **الأذن الصادرة:**
   - لا تتأثر بهذا التحديث
   - لها معالجة منفصلة في `MaterialMovement`

---

## الاختبار 🧪

### للتحقق من أن الكمية تم تحديثها:

```bash
# في Tinker
php artisan tinker

# تحقق من الكمية
$material = \App\Models\MaterialDetail::where('material_id', 1)->where('warehouse_id', 1)->first();
echo $material->quantity; // يجب أن تعكس آخر عملية

# تحقق من السجلات
\Illuminate\Support\Facades\Log::info('test');
```

---

## الخلاصة 🎯

✅ **الآن الكميات تنعكس بشكل صحيح على MaterialDetail**  
✅ **التعديلات تحدث الفروقات بدقة**  
✅ **الحذف يسترجع الكميات**  
✅ **كل العمليات مسجلة وآمنة**

