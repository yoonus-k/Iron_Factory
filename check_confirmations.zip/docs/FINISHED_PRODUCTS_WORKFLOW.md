# نظام إدارة المنتجات النهائية والإذونات الصادرة
**تاريخ الإنشاء:** 27 نوفمبر 2025  
**آخر تحديث:** 27 نوفمبر 2025

---

## 🔍 تحليل البنية الحالية

### ✅ الجداول الموجودة (لا داعي لإنشائها):

1. **`delivery_notes`** - إذونات التسليم (واردة/صادرة)
   - يحتوي على: note_number, material_id, delivered_weight, delivery_date, driver_name, vehicle_number, received_by
   - يُستخدم حالياً للمواد الخام الواردة

2. **`product_tracking`** - تتبع المنتج عبر المراحل
   - يحتوي على: barcode, stage, action, input_barcode, output_barcode, input_weight, output_weight, waste_amount, metadata
   - يتتبع المنتج من المستودع → Stage1 → Stage2 → Stage3 → Stage4

3. **`stage4_boxes`** - الكراتين من المرحلة الرابعة
   - يحتوي على: barcode, packaging_type, coils_count, total_weight, waste, status, customer_info, shipping_address, tracking_number
   - **الباركود:** `BOX4-XXX-2025` (يُولد تلقائياً)
   - **الحالات:** packing, packed, shipped, delivered

### 🎯 ما نحتاج إضافته:

بدلاً من إنشاء جداول جديدة، سنستخدم الجداول الموجودة ونضيف:
- **إعادة استخدام `delivery_notes`** للإذونات الصادرة (مع إضافة type = 'finished_product_outgoing')
- **إضافة customer_id** في `delivery_notes`
- **استخدام `product_tracking`** لتتبع خروج المنتج النهائي
- **تحديث status في `stage4_boxes`** عند الشحن

---

## 📋 تحليل الآلية المطلوبة

### 🔄 المراحل الرئيسية

#### **1️⃣ المرحلة الرابعة → المستودع (إذن استلام داخلي)**

**مدير الوردية/الشيفت:**
- يُنشئ إذن تسليم داخلي
- يحدد الكميات المنتجة (عدد الكراتين)
- يحدد نوع المنتج
- يرسل للتأكيد

**أمين المستودع:**
- يستلم إذن التسليم
- يؤكد الاستلام
- الكمية تُسجل في المستودع كـ "منتج نهائي"

---

#### **2️⃣ المستودع → العميل (إذن صادر للعميل)**

**أمين المستودع:**
- يُنشئ Delivery Note صادر
- يدخل البيانات:
  - الكميات والأنواع (من المخزون)
  - رقم لوحة السيارة
  - اختيار العميل (اختياري)
- حالة: "pending" (بانتظار الموافقة)

**الإدارة العليا (مدير أو صاحب صلاحية):**
- يراجع الإذن الصادر
- يؤكد العميل والكميات
- يعتمد الإذن → حالة "approved"
- يطبع الإذن

**السائق:**
- يستلم الإذن المطبوع مع البضاعة

---

## 🏗️ الهيكلية المقترحة للتطبيق

### **A. الجداول المطلوبة (Database Tables)**

#### **استخدام الجداول الموجودة:**

**1. تحديث `delivery_notes`** (موجود مسبقاً)
```sql
-- الحقول الموجودة:
- id
- note_number
- material_id
- delivered_weight
- delivery_date
- driver_name
- vehicle_number
- received_by
- timestamps

-- الحقول المطلوب إضافتها:
- type VARCHAR(50) DEFAULT 'incoming'  
  -- القيم: 'incoming', 'outgoing', 'internal_transfer', 'finished_product_outgoing'
  
- customer_id BIGINT UNSIGNED NULLABLE
  -- ربط بجدول customers (للإذونات الصادرة للعملاء)
  
- status VARCHAR(50) DEFAULT 'completed'
  -- القيم: 'pending', 'approved', 'rejected', 'completed', 'shipped'
  
- approved_by BIGINT UNSIGNED NULLABLE
  -- المدير الذي اعتمد الإذن
  
- approved_at TIMESTAMP NULLABLE
  -- تاريخ الاعتماد
  
- rejection_reason TEXT NULLABLE
  -- سبب الرفض إن وُجد
  
- print_count INT DEFAULT 0
  -- عدد مرات الطباعة
  
- source_type VARCHAR(50) NULLABLE
  -- 'stage4_box' للمنتجات النهائية
  
- source_id BIGINT UNSIGNED NULLABLE
  -- ID من جدول stage4_boxes
```

**2. استخدام `stage4_boxes`** (موجود مسبقاً)
```sql
-- الحقول الموجودة كافية:
- id
- barcode (BOX4-XXX-2025)
- packaging_type
- coils_count
- total_weight
- waste
- status (packing, packed, shipped, delivered)
- customer_info (بيانات العميل)
- shipping_address
- tracking_number
- created_by
- packed_at
- shipped_at
- timestamps

-- لا حاجة لتعديلات
```

**3. استخدام `product_tracking`** (موجود مسبقاً)
```sql
-- سنستخدمه لتتبع:
- خروج الكراتين من Stage 4 (stage='stage4', action='completed')
- نقل للمستودع (stage='warehouse', action='received')
- خروج للعميل (stage='warehouse', action='shipped')
```

#### **4. customers (جدول جديد - العملاء)**
```sql
- id
- customer_code (رمز العميل - تلقائي)
- name (الاسم)
- company_name (اسم الشركة)
- phone
- email (اختياري)
- address
- city
- country
- tax_number (الرقم الضريبي - اختياري)
- is_active (فعال / غير فعال)
- notes
- created_by
- timestamps
```

---

### **B. الصلاحيات المطلوبة (Permissions)**

#### **إدارة التسليم الداخلي:**
```php
1. CREATE_INTERNAL_DELIVERY
   - الوصف: إنشاء إذن تسليم داخلي من المرحلة 4
   - المستخدمون: مدير الوردية، مشرف الإنتاج
   - المجموعة: المنتجات النهائية

2. CONFIRM_INTERNAL_DELIVERY
   - الوصف: تأكيد استلام المنتجات في المستودع
   - المستخدمون: أمين المستودع
   - المجموعة: المنتجات النهائية

3. VIEW_FINISHED_PRODUCTS
   - الوصف: عرض المنتجات النهائية في المستودع
   - المستخدمون: أمين المستودع، الإدارة، التقارير
   - المجموعة: المنتجات النهائية
```

#### **إدارة الإذونات الصادرة:**
```php
4. CREATE_OUTGOING_DELIVERY
   - الوصف: إنشاء إذن صادر للعميل
   - المستخدمون: أمين المستودع
   - المجموعة: الإذونات الصادرة

5. APPROVE_OUTGOING_DELIVERY
   - الوصف: اعتماد الإذن الصادر
   - المستخدمون: المدير، نائب المدير
   - المجموعة: الإذونات الصادرة

6. REJECT_OUTGOING_DELIVERY
   - الوصف: رفض الإذن الصادر
   - المستخدمون: المدير، نائب المدير
   - المجموعة: الإذونات الصادرة

7. PRINT_OUTGOING_DELIVERY
   - الوصف: طباعة الإذن الصادر (بعد الاعتماد فقط)
   - المستخدمون: أمين المستودع، الإدارة
   - المجموعة: الإذونات الصادرة

8. VIEW_OUTGOING_DELIVERIES
   - الوصف: عرض جميع الإذونات الصادرة
   - المستخدمون: أمين المستودع، الإدارة
   - المجموعة: الإذونات الصادرة
```

#### **إدارة العملاء:**
```php
9. MANAGE_CUSTOMERS
   - الوصف: إضافة وتعديل وحذف العملاء
   - المستخدمون: الإدارة، المبيعات
   - المجموعة: العملاء

10. VIEW_CUSTOMERS
    - الوصف: عرض قائمة العملاء
    - المستخدمون: أمين المستودع، المبيعات، الإدارة
    - المجموعة: العملاء
```

---

### **C. Controllers المطلوبة**

#### **1. FinishedProductController**
```php
Namespace: Modules\Manufacturing\Http\Controllers

Methods:
- index()                      // عرض المنتجات في المستودع (مع فلترة)
- create()                     // صفحة إنشاء تسليم داخلي
- store(Request $request)      // حفظ التسليم الداخلي
- show($id)                    // عرض تفاصيل منتج
- confirm($id)                 // تأكيد الاستلام (أمين المستودع)
- pendingConfirmations()       // الإذونات بانتظار التأكيد
- getAvailableStock()          // API - جلب المخزون المتاح للإذن الصادر
```

#### **2. OutgoingDeliveryController**
```php
Namespace: Modules\Manufacturing\Http\Controllers

Methods:
- index()                      // عرض جميع الإذونات الصادرة
- create()                     // صفحة إنشاء إذن صادر جديد
- store(Request $request)      // حفظ الإذن (حالة pending)
- show($id)                    // عرض تفاصيل الإذن
- edit($id)                    // تعديل الإذن (قبل الاعتماد فقط)
- update(Request $request, $id)// تحديث الإذن
- approve($id)                 // اعتماد الإذن (الإدارة)
- reject($id)                  // رفض الإذن
- updateCustomer($id)          // تحديث العميل (الإدارة)
- print($id)                   // صفحة الطباعة
- pendingApproval()            // الإذونات بانتظار الاعتماد
- approved()                   // الإذونات المعتمدة
- shipped()                    // الإذونات المشحونة
```

#### **3. CustomerController**
```php
Namespace: App\Http\Controllers

Methods:
- index()                      // قائمة العملاء
- store(Request $request)      // إضافة عميل جديد
- update(Request $request, $id)// تعديل بيانات عميل
- destroy($id)                 // حذف عميل (soft delete)
- activate($id)                // تفعيل عميل
- deactivate($id)              // تعطيل عميل
- search(Request $request)     // API - بحث في العملاء
```

---

### **D. Models والعلاقات**

#### **1. FinishedProduct Model**
```php
namespace Modules\Manufacturing\Models;

Relations:
- belongsTo(Stage4Box::class, 'stage4_box_id')
- belongsTo(User::class, 'created_by')
- belongsTo(User::class, 'confirmed_by')
- belongsTo(Warehouse::class, 'warehouse_id')
- hasMany(OutgoingDeliveryItem::class)

Scopes:
- scopeInStock($query)         // status = 'in_stock'
- scopeAvailable($query)       // in_stock & quantity > 0
- scopeByProductType($query, $type)

Attributes:
- remaining_quantity (calculated)
- is_available (boolean)
```

#### **2. OutgoingDeliveryNote Model**
```php
namespace Modules\Manufacturing\Models;

Relations:
- belongsTo(Customer::class, 'customer_id')
- belongsTo(User::class, 'created_by')
- belongsTo(User::class, 'approved_by')
- hasMany(OutgoingDeliveryItem::class, 'outgoing_delivery_note_id')

Scopes:
- scopePending($query)
- scopeApproved($query)
- scopeRejected($query)
- scopeShipped($query)

Methods:
- approve(User $user)          // اعتماد الإذن
- reject(User $user, $reason)  // رفض الإذن
- canEdit()                    // هل يمكن التعديل؟
- canPrint()                   // هل يمكن الطباعة؟
- canApprove()                 // هل يمكن الاعتماد؟
```

#### **3. OutgoingDeliveryItem Model**
```php
namespace Modules\Manufacturing\Models;

Relations:
- belongsTo(OutgoingDeliveryNote::class, 'outgoing_delivery_note_id')
- belongsTo(FinishedProduct::class, 'finished_product_id')
```

#### **4. Customer Model**
```php
namespace App\Models;

Relations:
- hasMany(OutgoingDeliveryNote::class)
- belongsTo(User::class, 'created_by')

Scopes:
- scopeActive($query)
- scopeSearch($query, $term)

Attributes:
- full_name (name + company_name)
- is_active (boolean)
```

---

### **E. الواجهات (Views) - الهيكل الكامل**

#### **1. المنتجات النهائية**
```
Modules/Manufacturing/resources/views/finished-products/
├── index.blade.php              // المنتجات في المستودع
│   ├── Filters: نوع المنتج، التاريخ، الحالة
│   ├── Table: المنتج، الكمية، التاريخ، الحالة، الإجراءات
│   └── Actions: عرض، تصدير
│
├── create.blade.php             // إنشاء تسليم داخلي جديد
│   ├── Form Fields:
│   │   ├── نوع المنتج (dropdown)
│   │   ├── عدد الكراتين (number)
│   │   ├── رقم الدفعة (auto/manual)
│   │   ├── تاريخ الإنتاج
│   │   ├── المستودع (dropdown)
│   │   └── ملاحظات (textarea)
│   └── Actions: حفظ، إلغاء
│
├── pending-confirmations.blade.php  // بانتظار تأكيد أمين المستودع
│   ├── Cards/Table: الإذونات المنتظرة
│   └── Action: زر "تأكيد الاستلام"
│
└── show.blade.php               // تفاصيل منتج نهائي
    ├── Info: النوع، الكمية، التاريخ
    ├── History: حركات الصرف
    └── Related: الإذونات الصادرة المرتبطة
```

#### **2. الإذونات الصادرة**
```
Modules/Manufacturing/resources/views/outgoing-deliveries/
├── index.blade.php              // جميع الإذونات الصادرة
│   ├── Tabs: الكل، بانتظار الاعتماد، معتمدة، مشحونة، مرفوضة
│   ├── Filters: رقم الإذن، العميل، التاريخ، الحالة
│   ├── Table: رقم الإذن، العميل، الكميات، الحالة، الإجراءات
│   └── Actions: عرض، تعديل، اعتماد، طباعة
│
├── create.blade.php             // إنشاء إذن صادر جديد
│   ├── Step 1: بيانات الإذن
│   │   ├── رقم السيارة (required)
│   │   ├── اسم السائق (optional)
│   │   ├── العميل (optional - select2)
│   │   └── ملاحظات
│   ├── Step 2: اختيار المنتجات
│   │   ├── جدول المنتجات المتاحة
│   │   ├── اختيار الكمية لكل منتج
│   │   └── إجمالي الكراتين (auto-calculate)
│   └── Actions: حفظ كمسودة، إرسال للاعتماد
│
├── show.blade.php               // تفاصيل الإذن الصادر
│   ├── Header: رقم الإذن، الحالة، التاريخ
│   ├── Customer Info: العميل (إذا محدد)
│   ├── Vehicle Info: رقم السيارة، السائق
│   ├── Items Table: المنتجات والكميات
│   ├── Actions Bar:
│   │   ├── [pending] تعديل، حذف، إرسال للاعتماد
│   │   ├── [pending - admin] اعتماد، رفض، تعديل العميل
│   │   └── [approved] طباعة، تحديث العميل
│   └── Timeline: سجل الإجراءات
│
├── edit.blade.php               // تعديل الإذن (قبل الاعتماد)
│   └── نفس create.blade.php مع البيانات محملة
│
├── pending-approval.blade.php   // للإدارة - الإذونات بانتظار الاعتماد
│   ├── Cards: كل إذن في كارد منفصل
│   ├── Quick Actions: اعتماد سريع، رفض، عرض التفاصيل
│   └── Notifications: تنبيهات للإذونات الجديدة
│
├── approved.blade.php           // الإذونات المعتمدة
│   └── Table مع إمكانية الطباعة والتصدير
│
└── print.blade.php              // نموذج الطباعة
    ├── Header: شعار الشركة، رقم الإذن، التاريخ
    ├── Customer Info
    ├── Vehicle & Driver Info
    ├── Items Table
    ├── Total Boxes
    ├── Notes
    ├── Signatures: أمين المستودع، المدير، السائق
    └── Footer: شروط وأحكام (اختياري)
```

#### **3. العملاء**
```
resources/views/customers/
├── index.blade.php              // قائمة العملاء
│   ├── Search: بحث بالاسم/الشركة/الهاتف
│   ├── Filters: فعال/غير فعال
│   ├── Table: الرمز، الاسم، الشركة، الهاتف، الحالة، الإجراءات
│   └── Actions: إضافة، تعديل، تفعيل/تعطيل
│
└── partials/
    └── customer-modal.blade.php // Modal للإضافة/التعديل
        ├── Form Fields:
        │   ├── الاسم (required)
        │   ├── اسم الشركة (optional)
        │   ├── الهاتف (required)
        │   ├── البريد الإلكتروني (optional)
        │   ├── العنوان
        │   ├── المدينة
        │   ├── الدولة
        │   ├── الرقم الضريبي (optional)
        │   └── ملاحظات
        └── Actions: حفظ، إلغاء
```

---

## 🔄 سير العمل الكامل (Workflow)

### **السيناريو التفصيلي:**

```
┌─────────────────────────────────────────────────────────────────┐
│ المرحلة 4: التعبئة (Stage 4 - Packaging)                       │
│ ✅ إتمام عملية التعبئة                                          │
│ ✅ تسجيل عدد الكراتين المنتجة                                   │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ مدير الوردية / الشيفت (CREATE_INTERNAL_DELIVERY)              │
│ 1. يفتح صفحة "تسليم داخلي جديد"                                │
│ 2. يدخل البيانات:                                              │
│    • نوع المنتج (مثال: كراتين حديد 10x10)                      │
│    • عدد الكراتين: 300                                          │
│    • رقم الدفعة: تلقائي أو يدوي                                 │
│    • المستودع المستهدف                                          │
│ 3. يحفظ الإذن → الحالة: pending_confirmation                   │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ إشعار (Notification) → أمين المستودع                           │
│ "يوجد تسليم داخلي جديد بانتظار التأكيد"                        │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ أمين المستودع (CONFIRM_INTERNAL_DELIVERY)                      │
│ 1. يفتح صفحة "تأكيدات منتظرة"                                  │
│ 2. يراجع التفاصيل:                                             │
│    • نوع المنتج                                                 │
│    • العدد المذكور                                              │
│    • العد الفعلي (يمكن تعديله إذا كان هناك فرق)               │
│ 3. يؤكد الاستلام                                               │
│ → البيانات تُحفظ في جدول finished_products                     │
│ → الحالة: in_stock                                             │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ المنتجات موجودة الآن في المستودع (Available Stock)             │
│ يمكن للمستودع الآن إنشاء إذونات صادرة                          │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ أمين المستودع (CREATE_OUTGOING_DELIVERY)                       │
│ 1. يفتح "إنشاء إذن صادر جديد"                                  │
│ 2. يدخل بيانات الشحنة:                                         │
│    • رقم لوحة السيارة: ABC-1234 (required)                     │
│    • اسم السائق: محمد أحمد (optional)                           │
│    • العميل: [يمكن تركه فارغاً] (optional)                     │
│ 3. يختار المنتجات من المخزون المتاح:                           │
│    • نوع المنتج 1: 150 كرتونة                                  │
│    • نوع المنتج 2: 50 كرتونة                                   │
│    • نوع المنتج 3: 300 كرتونة                                  │
│    • الإجمالي: 500 كرتونة (يُحسب تلقائياً)                     │
│ 4. يحفظ الإذن → الحالة: pending                                │
│ → رقم الإذن: OUT-2025-0001 (تلقائي)                            │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ إشعار (Notification) → الإدارة العليا                          │
│ "إذن صادر جديد بانتظار الاعتماد - OUT-2025-0001"              │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ الإدارة العليا (APPROVE_OUTGOING_DELIVERY)                     │
│ 1. تفتح صفحة "إذونات بانتظار الاعتماد"                         │
│ 2. تراجع تفاصيل الإذن:                                         │
│    • الكميات والأنواع                                           │
│    • رقم السيارة                                                │
│    • العميل (إذا محدد)                                          │
│ 3. يمكنها:                                                      │
│    أ) اختيار/تعديل العميل إذا لم يكن محدداً                   │
│    ب) تعديل الكميات إذا لزم الأمر                              │
│ 4. تعتمد الإذن (Approve) أو ترفضه (Reject)                     │
│ → إذا اعتمدت: الحالة → approved                                │
│ → إذا رُفض: الحالة → rejected + سبب الرفض                      │
└─────────────────────────────────────────────────────────────────┘
                              ↓
          ┌─────────────────────────────────┐
          │  تم الاعتماد؟                   │
          └─────────────────────────────────┘
                 │                │
        ✅ نعم   │                │ ❌ لا
                 ↓                ↓
     ┌──────────────────┐  ┌──────────────────┐
     │ الحالة: approved │  │ الحالة: rejected │
     └──────────────────┘  └──────────────────┘
              ↓                     ↓
┌────────────────────────┐  ┌────────────────────────┐
│ يمكن الطباعة الآن      │  │ إشعار → أمين المستودع  │
│ (PRINT_OUTGOING_       │  │ "تم رفض الإذن + السبب" │
│  DELIVERY)             │  │ يمكن التعديل وإعادة    │
└────────────────────────┘  │ الإرسال                │
              ↓              └────────────────────────┘
┌─────────────────────────────────────────────────────────────────┐
│ الطباعة (Print)                                                 │
│ • يُطبع الإذن على ورقة A4                                       │
│ • يحتوي على:                                                    │
│   - رقم الإذن وتاريخه                                           │
│   - بيانات العميل                                               │
│   - رقم السيارة واسم السائق                                     │
│   - جدول المنتجات والكميات                                      │
│   - الإجمالي                                                     │
│   - توقيعات: (أمين المستودع، المدير، السائق)                   │
│ • عدد مرات الطباعة يُسجل (print_count)                          │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ تسليم الإذن للسائق                                             │
│ • السائق يستلم:                                                 │
│   - الإذن المطبوع                                               │
│   - البضاعة (الكراتين)                                          │
│ • الحالة تتحدث → shipped                                        │
│ • المخزون يتم تحديثه (finished_products.status → shipped)      │
└─────────────────────────────────────────────────────────────────┘
```

---

## ✅ خطة التطبيق بالترتيب

### **المرحلة 1: البنية التحتية (Infrastructure)**

#### **1.1 إنشاء/تعديل Migrations**
```bash
# فقط جدولين جديدين:
php artisan make:migration create_customers_table
php artisan make:migration add_finished_product_fields_to_delivery_notes

# لا حاجة لإنشاء finished_products أو outgoing_delivery_notes
# سنستخدم delivery_notes الموجود + stage4_boxes الموجود
```

**الترتيب:**
1. ✅ `delivery_notes` - موجود مسبقاً
2. ✅ `stage4_boxes` - موجود مسبقاً  
3. ✅ `product_tracking` - موجود مسبقاً
4. 🆕 `customers` - جدول جديد
5. 🔄 `delivery_notes` - إضافة حقول جديدة (type, customer_id, status, approved_by, etc.)

#### **1.2 إنشاء/تحديث Models**
```bash
# Models جديدة:
php artisan make:model App/Models/Customer

# Models موجودة - سنحدثها فقط:
# - App\Models\DeliveryNote (موجود)
# - App\Models\Stage4Box (موجود)
# - App\Models\ProductTracking (موجود)
```

#### **1.3 إضافة Permissions**
- تحديث `database/seeders/PermissionsSeeder.php`
- إضافة الصلاحيات العشرة المذكورة أعلاه

---

### **المرحلة 2: إدارة العملاء (Customers Management)**

#### **2.1 Controller**
```bash
php artisan make:controller CustomerController --resource
```

#### **2.2 Routes**
```php
// في routes/web.php
Route::middleware(['auth'])->group(function () {
    Route::resource('customers', CustomerController::class);
    Route::post('customers/{id}/activate', [CustomerController::class, 'activate'])->name('customers.activate');
    Route::post('customers/{id}/deactivate', [CustomerController::class, 'deactivate'])->name('customers.deactivate');
    Route::get('customers/search', [CustomerController::class, 'search'])->name('customers.search');
});
```

#### **2.3 Views**
- `resources/views/customers/index.blade.php`
- `resources/views/customers/partials/customer-modal.blade.php`

---

### **المرحلة 3: التسليم الداخلي (Internal Delivery - Stage 4 → Warehouse)**

#### **3.1 Controller**
```bash
php artisan make:controller Modules/Manufacturing/Http/Controllers/FinishedProductController
```

#### **3.2 Routes**
```php
// في Modules/Manufacturing/routes/web.php
Route::prefix('manufacturing/finished-products')->name('manufacturing.finished-products.')->group(function () {
    Route::get('/', [FinishedProductController::class, 'index'])->name('index');
    Route::get('create', [FinishedProductController::class, 'create'])->name('create');
    Route::post('/', [FinishedProductController::class, 'store'])->name('store');
    Route::get('{id}', [FinishedProductController::class, 'show'])->name('show');
    Route::get('pending-confirmations', [FinishedProductController::class, 'pendingConfirmations'])->name('pending-confirmations');
    Route::post('{id}/confirm', [FinishedProductController::class, 'confirm'])->name('confirm');
    Route::get('api/available-stock', [FinishedProductController::class, 'getAvailableStock'])->name('api.available-stock');
});
```

#### **3.3 Views**
- `Modules/Manufacturing/resources/views/finished-products/index.blade.php`
- `Modules/Manufacturing/resources/views/finished-products/create.blade.php`
- `Modules/Manufacturing/resources/views/finished-products/pending-confirmations.blade.php`
- `Modules/Manufacturing/resources/views/finished-products/show.blade.php`

---

### **المرحلة 4: الإذونات الصادرة (Outgoing Deliveries - Warehouse → Customer)**

#### **4.1 Controller**
```bash
php artisan make:controller Modules/Manufacturing/Http/Controllers/OutgoingDeliveryController
```

#### **4.2 Routes**
```php
// في Modules/Manufacturing/routes/web.php
Route::prefix('manufacturing/outgoing-deliveries')->name('manufacturing.outgoing-deliveries.')->group(function () {
    Route::get('/', [OutgoingDeliveryController::class, 'index'])->name('index');
    Route::get('create', [OutgoingDeliveryController::class, 'create'])->name('create');
    Route::post('/', [OutgoingDeliveryController::class, 'store'])->name('store');
    Route::get('{id}', [OutgoingDeliveryController::class, 'show'])->name('show');
    Route::get('{id}/edit', [OutgoingDeliveryController::class, 'edit'])->name('edit');
    Route::put('{id}', [OutgoingDeliveryController::class, 'update'])->name('update');
    
    // الإجراءات الخاصة
    Route::post('{id}/approve', [OutgoingDeliveryController::class, 'approve'])->name('approve');
    Route::post('{id}/reject', [OutgoingDeliveryController::class, 'reject'])->name('reject');
    Route::post('{id}/update-customer', [OutgoingDeliveryController::class, 'updateCustomer'])->name('update-customer');
    Route::get('{id}/print', [OutgoingDeliveryController::class, 'print'])->name('print');
    
    // الصفحات المفلترة
    Route::get('pending-approval', [OutgoingDeliveryController::class, 'pendingApproval'])->name('pending-approval');
    Route::get('approved', [OutgoingDeliveryController::class, 'approved'])->name('approved');
    Route::get('shipped', [OutgoingDeliveryController::class, 'shipped'])->name('shipped');
});
```

#### **4.3 Views**
- `Modules/Manufacturing/resources/views/outgoing-deliveries/index.blade.php`
- `Modules/Manufacturing/resources/views/outgoing-deliveries/create.blade.php`
- `Modules/Manufacturing/resources/views/outgoing-deliveries/show.blade.php`
- `Modules/Manufacturing/resources/views/outgoing-deliveries/edit.blade.php`
- `Modules/Manufacturing/resources/views/outgoing-deliveries/pending-approval.blade.php`
- `Modules/Manufacturing/resources/views/outgoing-deliveries/approved.blade.php`
- `Modules/Manufacturing/resources/views/outgoing-deliveries/print.blade.php`

---

### **المرحلة 5: التكامل والإشعارات (Integration & Notifications)**

#### **5.1 ربط Stage 4 مع التسليم الداخلي**
- إضافة زر "تسليم للمستودع" في صفحة Stage 4
- Auto-fill البيانات من Stage 4 عند إنشاء تسليم داخلي

#### **5.2 تحديث المخزون**
- عند تأكيد التسليم الداخلي → إضافة للمخزون
- عند اعتماد الإذن الصادر → خصم من المخزون وحجز الكمية
- عند الشحن → تحديث الحالة

#### **5.3 Notifications**
```php
// إشعارات مطلوبة:
1. تسليم داخلي جديد → أمين المستودع
2. إذن صادر بانتظار الاعتماد → الإدارة
3. إذن معتمد → أمين المستودع
4. إذن مرفوض → أمين المستودع
```

#### **5.4 Reports & Statistics**
- تقرير المنتجات النهائية (المخزون)
- تقرير الإذونات الصادرة (حسب الفترة)
- تقرير العملاء (أكثر العملاء طلباً)
- إحصائيات Dashboard

---

### **المرحلة 6: Sidebar Navigation**

#### **إضافة روابط في Sidebar:**

```blade
<!-- المنتجات النهائية -->
@if(auth()->user()->hasPermission('VIEW_FINISHED_PRODUCTS'))
<li>
    <a href="{{ route('manufacturing.finished-products.index') }}">
        <i class="fas fa-box-open"></i>
        <span>المنتجات النهائية</span>
    </a>
</li>
@endif

<!-- الإذونات الصادرة -->
@if(auth()->user()->hasPermission('VIEW_OUTGOING_DELIVERIES'))
<li>
    <a href="{{ route('manufacturing.outgoing-deliveries.index') }}">
        <i class="fas fa-truck-loading"></i>
        <span>الإذونات الصادرة</span>
    </a>
</li>
@endif

<!-- العملاء -->
@if(auth()->user()->hasPermission('VIEW_CUSTOMERS'))
<li>
    <a href="{{ route('customers.index') }}">
        <i class="fas fa-users"></i>
        <span>العملاء</span>
    </a>
</li>
@endif
```

---

## 🤔 أسئلة للتوضيح (يجب الإجابة عليها)

### **1. نوع المنتج:**
- ❓ هل يُحدد تلقائياً من Stage 4 (مثل: نوع الحديد، المقاس، إلخ)؟
- ❓ أم يُدخل يدوياً كـ text field؟
- **الاقتراح:** dropdown مع إمكانية الإضافة (مثل Product Types table)

### **2. رقم الباتش (Batch Number):**
- ❓ هل نحتاج batch number لكل مجموعة منتجات؟
- ❓ هل يُولد تلقائياً أم يدوياً؟
- **الاقتراح:** تلقائي بصيغة: `BATCH-YYYY-MM-XXXX`

### **3. المستودعات:**
- ❓ هل يوجد أكثر من مستودع للمنتجات النهائية؟
- ❓ أم مستودع واحد فقط؟
- **الاقتراح:** جدول warehouses موجود، يمكن الاختيار

### **4. الكميات الجزئية:**
- ❓ هل يمكن شحن جزء من كمية معينة لعدة عملاء؟
- مثال: 300 كرتونة → 150 للعميل A + 150 للعميل B
- **الاقتراح:** نعم، نسمح بذلك

### **5. العملاء:**
- ❓ هل توجد بيانات عملاء جاهزة أم نبدأ من الصفر؟
- ❓ هل يوجد integration مع CRM خارجي؟
- **الاقتراح:** نبدأ من الصفر بجدول customers

### **6. اختيار العميل:**
- ❓ هل اختيار العميل اختياري في البداية ويمكن تحديده لاحقاً من الإدارة؟
- ✅ حسب النص: نعم، اختياري عند الإنشاء، الإدارة تحدده عند الاعتماد

### **7. التعديلات بعد الاعتماد:**
- ❓ هل يمكن تعديل الإذن المعتمد (مثل تغيير العميل)؟
- **الاقتراح:** لا يمكن تعديل الكميات، فقط العميل (للإدارة فقط)

### **8. الطباعة:**
- ❓ كم نسخة تُطبع؟
- ❓ هل نحتاج watermark "نسخة أصلية" / "نسخة ثانية"؟
- **الاقتراح:** نسخة واحدة، يمكن إعادة الطباعة

---

## 📊 ملاحظات إضافية

### **Security:**
- جميع الإجراءات محمية بـ Permissions
- Middleware للتحقق من الصلاحيات
- CSRF protection على جميع POST requests
- Soft delete للعملاء والإذونات المرفوضة

### **Validation:**
- Server-side validation لجميع الـ forms
- Client-side validation للـ UX الأفضل
- التحقق من توفر المخزون قبل إنشاء الإذن الصادر

### **Logging:**
- تسجيل جميع الإجراءات (Create, Update, Approve, Reject)
- Activity Log لكل إذن
- Audit Trail للتتبع

### **Performance:**
- Indexes على الأعمدة المستخدمة في البحث
- Eager Loading للعلاقات
- Pagination للقوائم الطويلة
- Caching للإحصائيات

### **UI/UX:**
- تصميم responsive لجميع الشاشات
- تنبيهات واضحة للإجراءات الحرجة
- Loading states للـ AJAX requests
- Success/Error messages بعد كل إجراء

---

## 🚀 الخطوة التالية

**بعد الإجابة على الأسئلة أعلاه، سأبدأ بالتطبيق بالترتيب التالي:**

1. ✅ **Migrations** → إنشاء الجداول
2. ✅ **Models** → إنشاء الـ models والعلاقات
3. ✅ **Permissions** → إضافة الصلاحيات
4. ✅ **Customers** → إدارة العملاء أولاً (لأنها مستقلة)
5. ✅ **Finished Products** → التسليم الداخلي والمخزون
6. ✅ **Outgoing Deliveries** → الإذونات الصادرة
7. ✅ **Integration** → ربط كل شيء مع بعض
8. ✅ **Testing** → اختبار السيناريوهات

---

**تاريخ التحديث:** 27 نوفمبر 2025  
**الحالة:** بانتظار الموافقة والإجابة على الأسئلة  
**التقدير الزمني:** 8-12 ساعة عمل للتطبيق الكامل
