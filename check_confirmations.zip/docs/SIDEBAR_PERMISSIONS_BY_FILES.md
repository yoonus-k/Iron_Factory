# 📋 توثيق الصلاحيات حسب الملفات

## 1️⃣ ملفات الـ Roles

### `resources/views/roles/index.blade.php`
**وصف**: صفحة إدارة الأدوار (قائمة الأدوار)

**الصلاحيات المستخدمة**:
```blade
@if(canCreate('MANAGE_ROLES'))       // إنشاء دور جديد
@if(canUpdate('MANAGE_ROLES'))       // تعديل دور
@if(canDelete('MANAGE_ROLES') && !$role->is_system)  // حذف دور (ما عدا أدوار النظام)
```

**من يشوف الصفحة**:
- ✅ **Admin** (MANAGE_ROLES)
- ❌ **Manager** (لا يوجد)
- ❌ **Supervisor** (لا يوجد)
- ❌ **Worker** (لا يوجد)

**الصلاحيات المطلوبة في الـ Sidebar**:
```blade
@isAdmin
    <li>
        <a href="{{ route('roles.index') }}">
            <i class="fas fa-user-shield"></i> إدارة الأدوار
        </a>
    </li>
@endif
```

---

### `resources/views/roles/create.blade.php`
**وصف**: إضافة دور جديد

**الصلاحيات المستخدمة**:
```blade
// يفترض أن المستخدم قد تحقق من canCreate('MANAGE_ROLES') قبل الدخول
// لكن يمكن إضافة التحقق إضافياً
```

**من يشوف الصفحة**:
- ✅ **Admin** فقط

---

### `resources/views/roles/edit.blade.php`
**وصف**: تعديل دور

**الصلاحيات المستخدمة**:
```blade
// تعديل بيانات الدور
@canUpdate('MANAGE_ROLES')
    <button type="submit">حفظ</button>
@endcanUpdate

// إضافة صلاحيات للدور
// يمكن إضافة صلاحية جديدة مثل:
@if(canCreate('MANAGE_ROLES'))
```

**من يشوف الصفحة**:
- ✅ **Admin** فقط

---

## 2️⃣ ملفات الـ Permissions

### `resources/views/permissions/index.blade.php`
**وصف**: صفحة إدارة الصلاحيات (قائمة الصلاحيات)

**الصلاحيات المستخدمة**:
```blade
@if(canCreate('MANAGE_PERMISSIONS'))      // إضافة صلاحية جديدة
@if(canUpdate('MANAGE_PERMISSIONS'))      // تعديل صلاحية
@if(canDelete('MANAGE_PERMISSIONS') && !$permission->is_system)  // حذف صلاحية
```

**من يشوف الصفحة**:
- ✅ **Admin** (MANAGE_PERMISSIONS)
- ❌ **Manager** (لا يوجد)
- ❌ **Supervisor** (لا يوجد)
- ❌ **Worker** (لا يوجد)

**الصلاحيات المطلوبة في الـ Sidebar**:
```blade
@isAdmin
    <li>
        <a href="{{ route('permissions.index') }}">
            <i class="fas fa-key"></i> إدارة الصلاحيات
        </a>
    </li>
@endif
```

---

### `resources/views/permissions/create.blade.php`
**وصف**: إضافة صلاحية جديدة

**الصلاحيات المستخدمة**:
```blade
// يفترض أن المستخدم قد تحقق من canCreate('MANAGE_PERMISSIONS') قبل الدخول
```

**من يشوف الصفحة**:
- ✅ **Admin** فقط

---

### `resources/views/permissions/edit.blade.php`
**وصف**: تعديل صلاحية

**الصلاحيات المستخدمة**:
```blade
@canUpdate('MANAGE_PERMISSIONS')
    <button type="submit">حفظ التعديلات</button>
@endcanUpdate
```

**من يشوف الصفحة**:
- ✅ **Admin** فقط

---

## 3️⃣ ملف الـ Sidebar

### `resources/views/layout/sidebar.blade.php`
**وصف**: القائمة الجانبية (يظهر لجميع المستخدمين)

**الصلاحيات المستخدمة**:

#### لوحة التحكم
```blade
@canView('VIEW_MAIN_DASHBOARD')
    <li>
        <a href="/dashboard">{{ __('app.menu.dashboard') }}</a>
    </li>
@endcanView
```
- ✅ Admin, Manager, Supervisor, Worker

#### المستودع
```blade
@canView('MANAGE_WAREHOUSES')
    <li class="has-submenu">
        <!-- المحتوى -->
    </li>
@endcanView
```
- ✅ Admin, Manager
- ❌ Supervisor, Worker

#### المراحل (1-4)
```blade
@canView('STAGE1_STANDS')  // المرحلة الأولى
@canView('STAGE2_PROCESSING')  // المرحلة الثانية
@canView('STAGE3_COILS')  // المرحلة الثالثة
@canView('STAGE4_PACKAGING')  // المرحلة الرابعة
```
- ✅ Admin, Manager, Supervisor, Worker

#### تتبع الإنتاج
```blade
@canView('MANAGE_MOVEMENTS')
    <li class="has-submenu">
        <!-- المحتوى -->
    </li>
@endcanView
```
- ✅ Admin, Manager, Supervisor
- ❌ Worker

#### الهدر والجودة
```blade
@canView('VIEW_COSTS')
    <li class="has-submenu">
        <!-- المحتوى -->
    </li>
@endcanView
```
- ✅ Admin, Manager, Supervisor
- ❌ Worker

#### التقارير
```blade
@canView('VIEW_REPORTS')
    <li class="has-submenu">
        <!-- المحتوى -->
    </li>
@endcanView
```
- ✅ Admin, Manager, Supervisor
- ❌ Worker

#### الإدارة
```blade
@canView('MANAGE_USERS')
    <li class="has-submenu">
        <!-- إدارة المستخدمين -->
        @if(isAdmin())
            <!-- إدارة الأدوار والصلاحيات - Admin فقط -->
        @endif
    </li>
@endcanView
```
- ✅ Admin, Manager
- ❌ Supervisor, Worker

#### الإعدادات
```blade
@if(isAdmin())
    <li class="has-submenu">
        <!-- الإعدادات -->
    </li>
@endif
```
- ✅ Admin فقط
- ❌ Manager, Supervisor, Worker

---

## 📊 مصفوفة الصلاحيات الكاملة

```
┌─────────────────────────────────────────────────────────────────────┐
│                    صلاحيات الـ Sidebar                             │
├─────────────────────────────────────────────────────────────────────┤
│ الصلاحية           │ الكود                  │ A │ M │ S │ W │
├─────────────────────────────────────────────────────────────────────┤
│ لوحة التحكم         │ VIEW_MAIN_DASHBOARD    │ ✅│ ✅│ ✅│ ✅│
│ المستودع           │ MANAGE_WAREHOUSES      │ ✅│ ✅│ ❌│ ❌│
│ المرحلة الأولى      │ STAGE1_STANDS          │ ✅│ ✅│ ✅│ ✅│
│ المرحلة الثانية     │ STAGE2_PROCESSING      │ ✅│ ✅│ ✅│ ✅│
│ المرحلة الثالثة     │ STAGE3_COILS           │ ✅│ ✅│ ✅│ ✅│
│ المرحلة الرابعة     │ STAGE4_PACKAGING       │ ✅│ ✅│ ✅│ ✅│
│ تتبع الإنتاج       │ MANAGE_MOVEMENTS       │ ✅│ ✅│ ✅│ ❌│
│ الهدر والجودة      │ VIEW_COSTS             │ ✅│ ✅│ ✅│ ❌│
│ التقارير            │ VIEW_REPORTS           │ ✅│ ✅│ ✅│ ❌│
│ إدارة المستخدمين   │ MANAGE_USERS           │ ✅│ ✅│ ❌│ ❌│
│ إدارة الأدوار       │ MANAGE_ROLES           │ ✅│ ❌│ ❌│ ❌│
│ إدارة الصلاحيات    │ MANAGE_PERMISSIONS     │ ✅│ ❌│ ❌│ ❌│
│ الإعدادات           │ (isAdmin فقط)         │ ✅│ ❌│ ❌│ ❌│
├─────────────────────────────────────────────────────────────────────┤
│ المفتاح: A=Admin, M=Manager, S=Supervisor, W=Worker               │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🔐 نقاط الأمان المهمة

### 1. حماية الـ Routes
```php
// في routes/web.php أو routes/admin.php
Route::middleware(['auth', 'check.permission:MANAGE_ROLES'])->group(function () {
    Route::resource('roles', RoleController::class);
});

Route::middleware(['auth', 'check.permission:MANAGE_PERMISSIONS'])->group(function () {
    Route::resource('permissions', PermissionController::class);
});
```

### 2. حماية الـ Controllers
```php
public function index()
{
    if (!canRead('MANAGE_ROLES')) {
        abort(403, 'Unauthorized');
    }
    // ... الكود
}
```

### 3. حماية الـ API
```php
// في API routes
Route::middleware(['auth:sanctum', 'check.permission:MANAGE_ROLES'])
    ->get('/api/roles', [RoleController::class, 'index']);
```

---

## ✅ قائمة التحقق عند إضافة صفحة جديدة

- [ ] عرّف الصلاحيات المطلوبة
- [ ] أضفها في السيدر `FixSidebarPermissionsSeeder.php`
- [ ] اربطها بالأدوار بشكل صحيح
- [ ] استخدم `@canView`, `@canCreate`, etc. في الـ Blade
- [ ] احمِ الـ Routes بـ Middleware
- [ ] احمِ الـ Controllers بـ canRead, canCreate, etc.
- [ ] اختبر مع جميع الأدوار
- [ ] وثّق الصلاحيات هنا

---

**آخر تحديث**: 2025-11-24
**الحالة**: ✅ توثيق كامل لجميع الملفات
