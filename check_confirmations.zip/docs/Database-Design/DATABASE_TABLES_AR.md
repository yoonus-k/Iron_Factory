# 📊 شرح جداول قاعدة البيانات - نظام مصنع الحديد الذكي

> شرح تفصيلي بالعربية لجميع جداول قاعدة البيانات وعلاقاتها

---

## 🔐 جداول الصلاحيات والمستخدمين (6 جداول)

### 1️⃣ جدول `roles` - الأدوار الوظيفية

**الوصف:** يحتوي على تعريف جميع الأدوار في المصنع

**الحقول الرئيسية:**
- `role_name` - اسم الدور (مدير، مشرف، عامل، إلخ)
- `role_code` - رمز الدور (ADMIN, MANAGER, WORKER, إلخ)
- `level` - مستوى الصلاحية (0-100)
- `is_system` - هل هو دور نظام لا يمكن حذفه

**الأدوار الافتراضية:**
```
1. Admin (مدير النظام) - level: 100
2. Manager (مدير الإنتاج) - level: 80
3. Supervisor (مشرف) - level: 60
4. Worker (عامل) - level: 40
5. Warehouse Keeper (أمين مستودع) - level: 50
6. Accountant (محاسب) - level: 70
```

---

### 2️⃣ جدول `permissions` - الصلاحيات

**الوصف:** تعريف جميع الصلاحيات في النظام (27 صلاحية)

**الحقول الرئيسية:**
- `permission_code` - رمز الصلاحية
- `module` - الوحدة (users, roles, warehouses, materials, إلخ)
- `is_system` - هل هي صلاحية نظام

**الوحدات والصلاحيات:**
```
✓ users (5 صلاحيات): إدارة المستخدمين
✓ roles (5 صلاحيات): إدارة الأدوار
✓ warehouses (5 صلاحيات): إدارة المستودعات
✓ materials (5 صلاحيات): إدارة المواد
✓ production (3 صلاحيات): تتبع الإنتاج
✓ waste (2 صلاحيات): إدارة الهدر
✓ shifts (2 صلاحيات): إدارة الورديات
✓ reports (3 صلاحيات): عرض التقارير
✓ suppliers (2 صلاحيات): إدارة الموردين
✓ accounting (2 صلاحيات): العمليات المحاسبية
✓ settings (2 صلاحيات): إعدادات النظام
```

---

### 3️⃣ جدول `role_permissions` - ربط الأدوار بالصلاحيات

**الوصف:** جدول وسيط يحدد صلاحيات كل دور

**الحقول الرئيسية:**
- `role_id` - معرف الدور
- `permission_id` - معرف الصلاحية
- `can_create` - يمكن إنشاء
- `can_read` - يمكن قراءة/عرض
- `can_update` - يمكن تعديل
- `can_delete` - يمكن حذف
- `can_approve` - يمكن موافقة (للعمليات الحساسة)
- `can_export` - يمكن تصدير البيانات

**مثال:**
```
الدور: Manager
الصلاحية: materials
يمكن: read ✓, create ✓, update ✓, approve ✓, export ✓
لا يمكن: delete ✗
```

---

### 4️⃣ جدول `users` - المستخدمين/الموظفين

**الوصف:** بيانات جميع مستخدمي النظام

**الحقول الرئيسية:**
- `name` - اسم الموظف
- `email` - البريد الإلكتروني (فريد)
- `password` - كلمة المرور (مشفرة)
- `phone` - رقم الهاتف
- `role_id` - الدور الأساسي
- `is_active` - هل الموظف نشط
- `created_by` - من أنشأ الحساب

---

### 5️⃣ جدول `user_permissions` - صلاحيات إضافية

**الوصف:** صلاحيات خاصة لمستخدم معين (تجاوز صلاحيات الدور)

**الاستخدام:**
```
مثال: عامل عادي لكن نطيه صلاحية عرض التقارير
```

---

### 6️⃣ جدول `shift_assignments` - تعيين الورديات

**الوصف:** جدول الورديات لكل موظف

**الحقول الرئيسية:**
- `user_id` - معرف الموظف
- `shift_type` - نوع الوردية (صباحي، مسائي، ليلي)
- `shift_date` - تاريخ الوردية
- `start_time` - وقت البداية
- `end_time` - وقت النهاية
- `assigned_location` - مكان العمل (مرحلة الإنتاج)

---

## 📦 جداول المستودعات والمواد (9 جداول)

### 7️⃣ جدول `warehouses` - المستودعات

**الوصف:** بيانات جميع المستودعات

**الحقول الرئيسية:**
- `warehouse_code` - رمز المستودع (WH-MAIN-001)
- `warehouse_name` - اسم المستودع
- `warehouse_type` - نوع المستودع (raw_materials, additives, finished_goods)
- `location` - الموقع الجغرافي
- `capacity` - السعة التخزينية
- `capacity_unit` - وحدة السعة (kg)
- `is_active` - هل المستودع فعال

**المستودعات الافتراضية:**
```
1. WH-MAIN-001 - المستودع الرئيسي (مواد خام) - سعة: 50 طن
2. WH-ADD-002 - مستودع الإضافات (صبغة، بلاستيك) - سعة: 10 طن
3. WH-FIN-003 - مستودع المنتجات النهائية - سعة: 30 طن
```

---

### 8️⃣ جدول `material_types` - أنواع المواد

**الوصف:** تصنيف أنواع المواد المستخدمة

**الحقول الرئيسية:**
- `type_code` - رمز النوع (MT-WIRE-001)
- `type_name` - اسم النوع
- `category` - التصنيف (raw_material, additive)
- `specifications` - المواصفات التقنية (JSON)
- `default_unit` - الوحدة الافتراضية (kg)
- `standard_cost` - التكلفة القياسية
- `storage_conditions` - شروط التخزين
- `shelf_life_days` - مدة الصلاحية بالأيام

**الأنواع الافتراضية:**
```
1. MT-WIRE-001 - سلك حديد (2.5-4 مم)
2. MT-DYE-001 - صبغة ملونة (6 ألوان)
3. MT-PLS-001 - بلاستيك طلاء (PVC)
4. MT-STEEL-001 - قضبان حديد
```

---

### 9️⃣ جدول `units` - وحدات القياس

**الوصف:** جميع وحدات القياس في النظام

**الحقول الرئيسية:**
- `unit_code` - رمز الوحدة (KG, TON, METER, إلخ)
- `unit_name` - الاسم بالعربي
- `unit_symbol` - الرمز المختصر
- `unit_type` - نوع الوحدة (weight, length, count, volume, area)
- `conversion_factor` - معامل التحويل للوحدة الأساسية
- `base_unit` - الوحدة الأساسية

**الوحدات الافتراضية:**
```
📊 وزن:
- KG (كيلوجرام) - الأساسية
- TON (طن) = 1000 كجم
- GRAM (جرام) = 0.001 كجم

📏 طول:
- METER (متر) - الأساسية
- CM (سنتيمتر) = 0.01 متر
- MM (مليمتر) = 0.001 متر

📦 عدد:
- PIECE (قطعة)
- BOX (كرتون)
- COIL (كويل)

💧 حجم:
- LITER (لتر)

📐 مساحة:
- SQM (متر مربع)
```

---

### 🔟 جدول `materials` - المواد الخام

**الوصف:** تفاصيل المواد المتوفرة في المصنع

**الحقول الرئيسية:**
- `material_code` - رمز المادة
- `material_name` - اسم المادة
- `material_type_id` - نوع المادة (FK)
- `unit_id` - وحدة القياس (FK)
- `current_quantity` - الكمية الحالية
- `reorder_quantity` - كمية إعادة الطلب
- `created_by` - من أضاف المادة

---

### 1️⃣1️⃣ جدول `material_details` ⭐ - تفاصيل المواد في المستودعات

**الوصف:** **الجدول الجديد** - يتتبع كمية كل مادة في كل مستودع

**الحقول الرئيسية:**
- `warehouse_id` - معرف المستودع (FK)
- `material_id` - معرف المادة (FK)
- `quantity` - الكمية المتوفرة الآن
- `min_quantity` - الحد الأدنى للكمية (ينبّه عند الانخفاض)
- `max_quantity` - الحد الأقصى للكمية
- `location_in_warehouse` - الموقع داخل المستودع (رف، قسم)
- `last_stock_check` - آخر جرد
- `notes` - ملاحظات

**مثال:**
```
المستودع: WH-MAIN-001
المادة: MT-WIRE-001 (سلك حديد)
الكمية الحالية: 500 كجم
الحد الأدنى: 200 كجم
الحد الأقصى: 1000 كجم
الموقع: رف A3
```

---

### 1️⃣2️⃣ جدول `delivery_notes` - سندات التوريد

**الوصف:** سندات استلام المواد من الموردين

**الحقول الرئيسية:**
- `delivery_note_code` - رمز السند
- `supplier_id` - معرف المورد (FK)
- `warehouse_id` - المستودع المستقبل (FK)
- `delivery_date` - تاريخ الاستلام
- `total_quantity` - إجمالي الكمية
- `notes` - ملاحظات
- `status` - الحالة (pending, received, verified, rejected)

---

### 1️⃣3️⃣ جدول `warehouse_transactions` - حركات المستودع

**الوصف:** تسجيل جميع عمليات المستودع

**الحقول الرئيسية:**
- `transaction_code` - رمز الحركة
- `transaction_type` - نوع الحركة (input, output, transfer, adjustment)
- `warehouse_from_id` - المستودع المصدر (للنقل)
- `warehouse_to_id` - المستودع الوجهة (للنقل)
- `material_id` - المادة (FK)
- `quantity` - الكمية
- `unit_id` - الوحدة (FK)
- `reference_id` - مرجع الحركة (رقم سند توريد، إلخ)
- `transaction_date` - تاريخ الحركة
- `created_by` - من سجل الحركة

**أنواع الحركات:**
```
📥 input - إدخال (استقبال من مورد)
📤 output - إخراج (للإنتاج)
🔄 transfer - نقل بين مستودعات
⚙️ adjustment - تعديل (جرد)
```

---

### 1️⃣4️⃣ جدول `suppliers` - الموردين

**الوصف:** بيانات جميع الموردين

**الحقول الرئيسية:**
- `supplier_code` - رمز المورد
- `supplier_name` - اسم المورد
- `supplier_type` - نوع المورد (raw_materials, additives, packaging)
- `contact_name` - اسم جهة الاتصال
- `phone` - رقم الهاتف
- `email` - البريد الإلكتروني
- `address` - العنوان
- `city` - المدينة
- `payment_terms` - شروط الدفع (cash, 30days, 60days)
- `is_active` - هل المورد فعال

---

### 1️⃣5️⃣ جدول `purchase_invoices` - فواتير الشراء

**الوصف:** فواتير شراء المواد من الموردين

**الحقول الرئيسية:**
- `invoice_number` - رقم الفاتورة
- `supplier_id` - معرف المورد (FK)
- `invoice_date` - تاريخ الفاتورة
- `due_date` - تاريخ الاستحقاق
- `total_amount` - الإجمالي
- `status` - الحالة (pending, partial, paid, cancelled)
- `payment_date` - تاريخ الدفع
- `created_by` - من أنشأ الفاتورة

---

## ⚙️ جداول الإنتاج (7 جداول)

### 1️⃣6️⃣ جدول `stage1_stands` - المرحلة الأولى: السلك الخام

**الوصف:** استقبال السلك الخام من المستودع ليبدأ الإنتاج

**الباركود:** `ST1-XXX-2025` (ST1 = Stage 1)

**الحقول الرئيسية:**
- `barcode` - الباركود الفريد
- `material_id` - المادة (سلك حديد) (FK)
- `warehouse_id` - المستودع المصدر (FK)
- `initial_weight` - الوزن الأولي
- `wire_diameter` - قطر السلك (مم)
- `wire_length` - طول السلك (متر)
- `batch_number` - رقم الدفعة
- `status` - الحالة (created, in_process, completed)
- `created_by` - من بدأ المرحلة

**سير العمل:**
```
1. استقبال السلك من المستودع
2. وزن وقياس المادة
3. تسجيل في النظام
4. نقل للمرحلة الثانية
```

---

### 1️⃣7️⃣ جدول `stage2_processed` - المرحلة الثانية: السلك المعالج

**الوصف:** معالجة السلك (سحب، معالجة حرارية)

**الباركود:** `ST2-XXX-2025` (ST2 = Stage 2)

**الحقول الرئيسية:**
- `barcode` - الباركود الفريد
- `parent_barcode` - الباركود من المرحلة 1
- `stage1_id` - معرف السلك الأول (FK)
- `processed_weight` - الوزن بعد المعالجة
- `processing_type` - نوع المعالجة (drawing, heating, annealing)
- `processing_duration` - مدة المعالجة (دقيقة)
- `processing_temp` - درجة الحرارة (للمعالجة الحرارية)
- `waste_weight` - وزن الهدر
- `waste_percentage` - نسبة الهدر
- `status` - الحالة
- `created_by` - من قام بالمعالجة

**حساب الهدر:**
```
الهدر = الوزن الأولي - الوزن بعد المعالجة
نسبة الهدر = (الهدر / الوزن الأولي) × 100
```

---

### 1️⃣8️⃣ جدول `additives_inventory` - مخزون الإضافات

**الوصف:** مخزون الصبغة والبلاستيك المستخدمة في الإنتاج

**الحقول الرئيسية:**
- `additive_type` - نوع الإضافة (dye, plastic)
- `additive_name` - اسم الإضافة (أحمر، أزرق، إلخ)
- `warehouse_id` - المستودع (FK)
- `current_quantity` - الكمية الحالية
- `unit_id` - وحدة القياس (kg)
- `batch_number` - رقم الدفعة
- `expiry_date` - تاريخ الانتهاء
- `last_restocked` - آخر تجديد

---

### 1️⃣9️⃣ جدول `stage3_coils` - المرحلة الثالثة: الكويلات

**الوصف:** تصنيع الكويلات بإضافة الصبغة والبلاستيك

**الباركود:** `CO3-XXX-2025` (CO3 = Coil 3)

**الحقول الرئيسية:**
- `barcode` - الباركود الفريد
- `parent_barcode` - الباركود من المرحلة 2
- `stage2_id` - معرف السلك المعالج (FK)
- `coil_number` - رقم الكويل
- `wire_size` - قياس السلك
- `base_weight` - الوزن الأساسي (من المرحلة 2)
- `dye_weight` - وزن الصبغة المضافة
- `dye_type` - نوع الصبغة
- `plastic_weight` - وزن البلاستيك المضاف
- `plastic_type` - نوع البلاستيك
- `total_weight` - الوزن الإجمالي
- `color` - اللون النهائي
- `waste` - الهدر
- `status` - الحالة
- `completed_at` - وقت الانتهاء
- `created_by` - من قام بالعملية

**حساب الوزن:**
```
الوزن الإجمالي = الوزن الأساسي + وزن الصبغة + وزن البلاستيك
```

---

### 2️⃣0️⃣ جدول `stage4_boxes` - المرحلة الرابعة: التعبئة

**الوصف:** تعبئة الكويلات في كراتين للشحن

**الباركود:** `BOX4-XXX-2025` (BOX4 = Box 4)

**الحقول الرئيسية:**
- `barcode` - الباركود الفريد للكرتون
- `box_number` - رقم الكرتون
- `box_type` - نوع الكرتون (standard, reinforced, custom)
- `coils_count` - عدد الكويلات في الكرتون
- `total_weight` - الوزن الإجمالي
- `dimensions` - الأبعاد (طول × عرض × ارتفاع)
- `destination` - العميل/الوجهة
- `invoice_id` - رقم الفاتورة (FK)
- `status` - الحالة (packing, ready, shipped)
- `shipped_date` - تاريخ الشحن
- `created_by` - من قام بالتعبئة

---

### 2️⃣1️⃣ جدول `box_coils` - تفاصيل الكويلات في كل كرتون

**الوصف:** جدول وسيط يربط الكويلات بالكراتين

**الحقول الرئيسية:**
- `box_id` - معرف الكرتون (FK)
- `coil_id` - معرف الكويل (FK)
- `sequence_number` - رقم ترتيب الكويل داخل الكرتون
- `coil_weight` - وزن الكويل
- `color` - اللون

**مثال:**
```
الكرتون: BOX4-001-2025
يحتوي على:
- كويل 1: CO3-100-2025 (وزن: 250 كجم، لون: أحمر)
- كويل 2: CO3-101-2025 (وزن: 245 كجم، لون: أحمر)
- كويل 3: CO3-102-2025 (وزن: 248 كجم، لون: أحمر)
الوزن الإجمالي: 743 كجم
```

---

## 📊 جداول التتبع والرقابة (4 جداول)

### 2️⃣2️⃣ جدول `waste_limits` - حدود الهدر

**الوصف:** تحديد النسب المسموحة للهدر في كل مرحلة

**الحقول الرئيسية:**
- `stage_name` - المرحلة (stage1, stage2, stage3, stage4)
- `max_waste_percentage` - النسبة المسموح بها
- `alert_threshold` - نسبة التنبيه (ينبّه قبل الوصول للحد الأقصى)
- `requires_approval` - هل يحتاج موافقة عند التجاوز
- `approved_by` - من صرح بالحد الأقصى
- `is_active` - هل الحد فعال

**القيم الافتراضية:**
```
المرحلة 1 (المعالجة): حد أقصى 2%
المرحلة 2 (السحب): حد أقصى 3%
المرحلة 3 (الصبغ): حد أقصى 5%
المرحلة 4 (التعبئة): حد أقصى 1%
```

---

### 2️⃣3️⃣ جدول `waste_tracking` - تتبع الهدر

**الوصف:** تسجيل كل عملية هدر بالتفصيل

**الحقول الرئيسية:**
- `waste_code` - رمز الهدر
- `stage_id` - المرحلة التي حدث فيها الهدر (FK)
- `waste_quantity` - كمية الهدر
- `waste_percentage` - نسبة الهدر
- `waste_reason` - السبب (manufacturing_defect, quality_issue, equipment_failure, operator_error)
- `waste_date` - تاريخ الهدر
- `status` - الحالة (pending_approval, approved, rejected)
- `approved_by` - من وافق عليه
- `notes` - ملاحظات
- `created_by` - من سجل الهدر

**تنبيهات تلقائية:**
```
⚠️ إذا الهدر < 1%: تصريح تلقائي
⚠️ إذا 1% < الهدر < الحد الأقصى: ينتظر موافقة المشرف
🔴 إذا الهدر > الحد الأقصى: ينبّه المدير فوراً
```

---

### 2️⃣4️⃣ جدول `shift_handovers` - تسليم الورديات

**الوصف:** تسجيل تسليم الوردية من فريق لآخر

**الحقول الرئيسية:**
- `handover_code` - رمز التسليم
- `shift_from_id` - الوردية المنتهية (FK)
- `shift_to_id` - الوردية الجديدة (FK)
- `handover_date` - تاريخ التسليم
- `total_produced` - الكمية المنتجة في الوردية
- `total_waste` - إجمالي الهدر
- `equipment_status` - حالة الآلات
- `issues_reported` - المشاكل المسجلة
- `notes` - ملاحظات عامة
- `created_by` - من استقبل الوردية

**معلومات الوردية:**
```
🕐 الوردية الصباحية: 6 صباحًا - 2 مساءً
🕐 الوردية المسائية: 2 مساءً - 10 مساءً
🕐 الوردية الليلية: 10 مساءً - 6 صباحًا
```

---

### 2️⃣5️⃣ جدول `operation_logs` - سجل العمليات (Audit Log)

**الوصف:** تسجيل جميع العمليات في النظام لأغراض المراجعة والأمان

**الحقول الرئيسية:**
- `log_code` - رمز السجل
- `user_id` - معرف المستخدم (FK)
- `action_type` - نوع العملية (create, read, update, delete, approve, export)
- `module_name` - الوحدة (users, materials, production, إلخ)
- `record_id` - معرف السجل المتأثر
- `old_values` - القيم القديمة (JSON)
- `new_values` - القيم الجديدة (JSON)
- `ip_address` - عنوان IP
- `user_agent` - بيانات المتصفح
- `action_date` - تاريخ ووقت العملية
- `status` - الحالة (success, failed)

**مثال:**
```
المستخدم: أحمد محمد
العملية: تعديل
الوحدة: materials
السجل: MT-WIRE-001
من: quantity = 500 kg
إلى: quantity = 250 kg
التاريخ: 2025-11-13 14:30:45
```

---

## 📈 جداول التقارير والإعدادات (4 جداول)

### 2️⃣6️⃣ جدول `generated_reports` - التقارير المولدة

**الوصف:** حفظ التقارير التي تم إنشاؤها

**الحقول الرئيسية:**
- `report_code` - رمز التقرير
- `report_type` - نوع التقرير (production, waste, inventory, financial)
- `title` - عنوان التقرير
- `start_date` - تاريخ البداية
- `end_date` - تاريخ النهاية
- `format` - الصيغة (PDF, Excel, HTML)
- `file_path` - مسار الملف
- `total_records` - عدد السجلات
- `created_by` - من أنشأ التقرير
- `created_at` - تاريخ الإنشاء

**أنواع التقارير:**
```
📊 تقارير الإنتاج:
  - الإنتاج اليومي/الأسبوعي/الشهري
  - الإنتاج حسب المرحلة
  - الإنتاج حسب الفريق

🗑️ تقارير الهدر:
  - الهدر بالكمية والنسبة
  - أسباب الهدر
  - المراحل الأكثر إنتاجًا للهدر

📦 تقارير المستودعات:
  - رصيد المواد
  - الحركات والتحويلات
  - التنبيهات (كميات منخفضة)

💰 تقارير مالية:
  - تكلفة الإنتاج
  - تكلفة المواد
  - تكلفة الهدر
```

---

### 2️⃣7️⃣ جدول `daily_statistics` - الإحصائيات اليومية

**الوصف:** إحصائيات كل يوم (لتقارير سريعة)

**الحقول الرئيسية:**
- `statistics_date` - تاريخ الإحصائية
- `shift_type` - الوردية
- `total_input_weight` - المادة الخام المستخدمة
- `total_output_weight` - الإنتاج النهائي
- `total_waste_weight` - الهدر الكلي
- `waste_percentage` - نسبة الهدر
- `boxes_produced` - عدد الكراتين
- `coils_produced` - عدد الكويلات
- `efficiency_percentage` - نسبة الكفاءة
- `defects_count` - عدد العيوب
- `equipment_downtime` - وقت التوقف (دقيقة)

**حسابات مهمة:**
```
الكفاءة = (الإنتاج النهائي / المادة الخام) × 100
الهدر = المادة الخام - الإنتاج النهائي
```

---

### 2️⃣8️⃣ جدول `system_formulas` - المعادلات الحسابية

**الوصف:** حفظ المعادلات المستخدمة في الحسابات

**الحقول الرئيسية:**
- `formula_code` - رمز المعادلة
- `formula_name` - اسم المعادلة
- `formula_expression` - الصيغة الرياضية
- `formula_type` - النوع (weight_calculation, waste_calculation, efficiency_calculation)
- `variables` - المتغيرات (JSON)
- `description` - شرح المعادلة
- `is_active` - هل المعادلة فعالة
- `updated_by` - من عدل آخر مرة

**أمثلة على المعادلات:**
```
1. حساب الوزن النهائي للكويل:
   Total Weight = Base Weight + Dye Weight + Plastic Weight

2. حساب نسبة الهدر:
   Waste % = (Waste Weight / Initial Weight) × 100

3. حساب الكفاءة:
   Efficiency % = (Output Weight / Input Weight) × 100

4. حساب التكلفة لكل كجم:
   Cost per KG = Total Cost / Total Weight
```

---

### 2️⃣9️⃣ جدول `system_settings` - إعدادات النظام

**الوصف:** إعدادات عامة للنظام

**الحقول الرئيسية:**
- `setting_key` - مفتاح الإعداد (فريد)
- `setting_value` - قيمة الإعداد
- `setting_type` - نوع القيمة (string, number, boolean, json)
- `category` - الفئة
- `description` - الشرح
- `is_public` - هل يراها المستخدمون

**الإعدادات الممكنة:**
```
🏭 إعدادات الشركة:
- company_name: اسم الشركة
- company_address: العنوان
- company_phone: الهاتف

📊 إعدادات الباركود:
- barcode_prefix_warehouse: WH
- barcode_prefix_stage1: ST1
- barcode_prefix_stage2: ST2
- barcode_prefix_stage3: CO3
- barcode_prefix_stage4: BOX4

🗑️ إعدادات الهدر:
- default_waste_stage1: 2%
- default_waste_stage2: 3%
- default_waste_stage3: 5%
- auto_approve_waste_under: 1%

🔔 إعدادات الإخطارات:
- notification_email: البريد الإلكتروني للتنبيهات
- enable_sms_alerts: تفعيل التنبيهات عبر SMS
```

---

## 🔧 جداول Laravel الأساسية (2 جداول)

### 3️⃣0️⃣ جدول `cache` - التخزين المؤقت

**الوصف:** تخزين البيانات المؤقتة لتسريع النظام

---

### 3️⃣1️⃣ جدول `jobs` - قائمة المهام

**الوصف:** مهام تعمل في الخلفية مثل:
- إرسال الإيميلات
- إنشاء التقارير الكبيرة
- تنظيف البيانات القديمة

---

## 🔄 سير العمل الكامل في المصنع

```
┌─────────────────────────────────────────────────────────────┐
│                    المستودع الرئيسي                          │
│                   WH-MAIN-001                             │
│         (المواد الخام: السلك والقضبان)                       │
└─────────────────┬───────────────────────────────────────────┘
                  │ warehouse_transactions (input)
                  ↓
        ┌─────────────────────┐
        │   المرحلة الأولى     │
        │   ST1 (السلك الخام)  │
        │ stage1_stands       │
        │ الوزن الأولي: 1000 كجم│
        └─────────────┬───────┘
                      │
                      ↓ waste_tracking (هدر: 20 كجم)
        ┌─────────────────────┐
        │   المرحلة الثانية    │
        │  ST2 (المعالجة)     │
        │ stage2_processed    │
        │ وزن بعد المعالجة: 960 كجم
        └─────────────┬───────┘
                      │
                      ↓ waste_tracking (هدر: 28.8 كجم)
        ┌─────────────────────┐
        │   المرحلة الثالثة    │
        │ CO3 (الكويلات)      │
        │ stage3_coils        │
        │ + صبغة: 10 كجم      │
        │ + بلاستيك: 5 كجم    │
        │ الوزن النهائي: 946.2 كجم
        └─────────────┬───────┘
                      │
                      ↓ waste_tracking (هدر: 9.46 كجم)
        ┌─────────────────────┐
        │   المرحلة الرابعة    │
        │ BOX4 (التعبئة)      │
        │ stage4_boxes        │
        │ 3 كويلات لكل كرتون  │
        └─────────────┬───────┘
                      │
                      ↓ warehouse_transactions (output)
        ┌─────────────────────┐
        │   المستودع النهائي   │
        │  WH-FIN-003         │
        │ (المنتجات الجاهزة)   │
        └─────────────────────┘
                      │
                      ↓ shift_handovers (تسليم الوردية)
                    ✓ تقارير يومية
```

---

## 📋 ملخص الجداول حسب الفئة

| الفئة | عدد الجداول | الجداول |
|------|-----------|---------|
| 🔐 الصلاحيات | 6 | roles, permissions, role_permissions, users, user_permissions, shift_assignments |
| 📦 المستودعات | 9 | warehouses, material_types, units, materials, material_details, delivery_notes, warehouse_transactions, suppliers, purchase_invoices |
| ⚙️ الإنتاج | 7 | stage1_stands, stage2_processed, additives_inventory, stage3_coils, stage4_boxes, box_coils |
| 📊 التتبع | 4 | waste_limits, waste_tracking, shift_handovers, operation_logs |
| 📈 التقارير | 4 | generated_reports, daily_statistics, system_formulas, system_settings |
| 🔧 Laravel | 2 | cache, jobs, migrations |
| **الإجمالي** | **31** | **جدول** |

---

## 🎯 الحقول المشتركة في جميع الجداول

```php
// في معظم الجداول
$table->id();                                    // معرف فريد
$table->foreignId('created_by')->nullable()     // من أنشأ السجل
    ->constrained('users');                     // مرجع لجدول users
$table->timestamps();                           // created_at و updated_at
```

---

## 🔐 علاقات الجداول الرئيسية

```
users ──1:N──> role_permissions (عبر role_id)
users ──1:N──> warehouses (created_by)
users ──1:N──> stage1_stands (created_by)

warehouses ──1:N──> material_details
materials ──1:N──> material_details
materials ──1:N──> warehouse_transactions

suppliers ──1:N──> purchase_invoices
suppliers ──1:N──> delivery_notes

stage1_stands ──1:N──> stage2_processed
stage2_processed ──1:N──> stage3_coils
stage3_coils ──M:N──> stage4_boxes (عبر box_coils)

stage1_stands ──1:N──> waste_tracking
stage2_processed ──1:N──> waste_tracking
stage3_coils ──1:N──> waste_tracking
stage4_boxes ──1:N──> waste_tracking
```

---

**تاريخ الإنشاء:** 13 نوفمبر 2025  
**النظام:** مصنع الحديد الذكي  
**الإصدار:** 1.0
