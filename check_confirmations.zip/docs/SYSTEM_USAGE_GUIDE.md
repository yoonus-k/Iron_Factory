# 🏭 نظام التسجيل والتسوية - دليل الاستخدام الكامل

## 📋 محتويات التوثيق

1. [البدء السريع](#البدء-السريع)
2. [الملفات المُنشأة](#الملفات-المُنشأة)
3. [دليل الاستخدام](#دليل-الاستخدام)
4. [الميزات الرئيسية](#الميزات-الرئيسية)
5. [الأسئلة الشائعة](#الأسئلة-الشائعة)

---

## 🚀 البدء السريع

### 1. تشغيل الـ Migrations

```bash
# تشغيل كل الـ migrations الجديدة
php artisan migrate

# أو تشغيل migration معينة
php artisan migrate --path=database/migrations/2025_11_17_000001_add_reconciliation_fields_to_delivery_notes.php
php artisan migrate --path=database/migrations/2025_11_17_000002_create_reconciliation_logs_table.php
php artisan migrate --path=database/migrations/2025_11_17_000003_create_registration_logs_table.php
```

### 2. التحقق من الملفات

تأكد من وجود هذه الملفات:

```
✅ app/Models/ReconciliationLog.php
✅ app/Models/RegistrationLog.php
✅ Modules/Manufacturing/Http/Controllers/WarehouseRegistrationController.php
✅ Modules/Manufacturing/Http/Controllers/ReconciliationController.php
✅ Modules/Manufacturing/resources/views/warehouses/registration/pending.blade.php
✅ Modules/Manufacturing/resources/views/warehouses/registration/create.blade.php
✅ Modules/Manufacturing/resources/views/warehouses/registration/show.blade.php
✅ Modules/Manufacturing/resources/views/warehouses/reconciliation/index.blade.php
✅ Modules/Manufacturing/resources/views/warehouses/reconciliation/show.blade.php
```

### 3. إضافة الروابط في الـ Navigation

في ملف الـ sidebar أو الـ navigation، أضف:

```blade
<!-- التسجيل والتسوية -->
<li class="nav-item">
    <a class="nav-link" href="{{ route('manufacturing.warehouse.registration.pending') }}">
        📦 تسجيل البضاعة
    </a>
</li>
<li class="nav-item">
    <a class="nav-link" href="{{ route('manufacturing.warehouses.reconciliation.index') }}">
        🔄 تسوية البضاعة
    </a>
</li>
```

---

## 📁 الملفات المُنشأة

### Database Migrations

| الملف | الوصف |
|--------|--------|
| `2025_11_17_000001_add_reconciliation_fields_to_delivery_notes.php` | إضافة 14 حقل جديد لـ delivery_notes |
| `2025_11_17_000002_create_reconciliation_logs_table.php` | جدول تسجيل التسويات |
| `2025_11_17_000003_create_registration_logs_table.php` | جدول تسجيل عملية التسجيل |

### Models

| الملف | الوصف |
|--------|--------|
| `app/Models/ReconciliationLog.php` | Model لسجلات التسوية (جديد) |
| `app/Models/RegistrationLog.php` | Model لسجلات التسجيل (جديد) |
| `app/Models/DeliveryNote.php` | تحديث بـ 23 حقل وعلاقات جديدة |
| `app/Models/PurchaseInvoice.php` | تحديث بـ methods جديدة |

### Controllers

| الملف | الوصف |
|--------|--------|
| `WarehouseRegistrationController.php` | 7 methods لتسجيل البضاعة |
| `ReconciliationController.php` | 6 methods لتسوية البضاعة |

### Views

| المسار | الوصف |
|---------|--------|
| `registration/pending.blade.php` | قائمة الشحنات المعلقة والمسجلة |
| `registration/create.blade.php` | نموذج تسجيل شحنة جديدة |
| `registration/show.blade.php` | عرض تفاصيل التسجيل |
| `reconciliation/index.blade.php` | لوحة التسوية |
| `reconciliation/show.blade.php` | لوحة التسوية التفصيلية |

---

## 📖 دليل الاستخدام

### 👤 أمين المستودع (Warehouse Manager)

#### الخطوة 1: عرض الشحنات المعلقة
```
اذهب إلى: 📦 تسجيل البضاعة
ستجد:
  - الشحنات المعلقة (بانتظار التسجيل)
  - الشحنات المسجلة بالفعل
```

#### الخطوة 2: تسجيل شحنة جديدة
```
اضغط على: 📝 تسجيل
أملا البيانات:
  ✅ الوزن الفعلي (من الميزان) - إجباري
  ✅ نوع المادة - إجباري
  ✅ موقع التخزين - إجباري
  ⭕ ملاحظات - اختياري
ثم: اضغط تسجيل الآن
```

#### الخطوة 3: نقل البضاعة للإنتاج
```
بعد التسجيل:
  1. اضغط على الشحنة المسجلة
  2. اضغط على: 🏭 نقل للإنتاج
النتيجة: 
  - حالة التسجيل: in_production
  - البضاعة جاهزة للإنتاج
```

---

### 📊 المحاسب (Accountant)

#### الخطوة 1: عرض لوحة التسوية
```
اذهب إلى: 🔄 تسوية البضاعة
ستجد:
  - إحصائيات سريعة
  - قائمة التسويات المعلقة
  - فلاتر البحث
```

#### الخطوة 2: ربط فاتورة
```
1. انسخ بيانات الفاتورة من المورد
2. في لوحة التسوية، اضغط على الشحنة
3. أدخل:
   - رقم الفاتورة
   - الوزن من الفاتورة
4. اضغط: Link & Calculate
```

---

### 👨‍💼 مدير الإنتاج (Production Manager)

#### الخطوة 1: مراجعة التسويات المعلقة
```
اذهب إلى: 🔄 تسوية البضاعة
اختر التسويات بحالة "discrepancy" ⚠️
```

#### الخطوة 2: اتخاذ قرار
```
ستجد لك جدول المقارنة:

| البيان | الفعلي | الفاتورة | الفرق | النسبة |
|--------|--------|----------|--------|---------|
| الوزن | 1000 | 1050 | +50 | +5.0% |

اختر من 3 خيارات:

1. ✓ قبول الفرق
   → reconciliation_status = "adjusted"
   → جاهز للدفع

2. ✗ رفض الفاتورة
   → reconciliation_status = "rejected"
   → ترجع للمورد

3. 🔧 تعديل البيانات
   → عديّل الوزن يدوياً
   → وضح السبب
```

---

## ✨ الميزات الرئيسية

### 1️⃣ تسجيل آلي
```
- كل شحنة لازم تُسجَّل قبل ما تطلع المستودع
- تسجيل تلقائي للوزن من الميزان
- سجل audit trail لكل عملية تسجيل
```

### 2️⃣ حسابات تلقائية
```
- حساب الفرق تلقائياً من قاعدة البيانات
- حساب النسبة المئوية
- حساب التأثير المالي
```

### 3️⃣ تصنيف ذكي للفروقات
```
- < 1%   → تقبل تلقائياً (matched)
- 1-5%   → تحتاج موافقة (discrepancy)
- > 5%   → تحذير (requires_review)
```

### 4️⃣ تقارير شاملة
```
- أداء الموردين
- التسويات المكتملة
- الفروقات الكبيرة
- الإحصائيات اليومية
```

### 5️⃣ Audit Trail كامل
```
- كل تسجيل مسجّل
- كل قرار مسجّل
- معلومات المستخدم والوقت
- IP Address للأمان
```

---

## ❓ الأسئلة الشائعة

### س: ماذا يحدث إذا لم تسجّل البضاعة؟
**ج:** النظام يمنع نقلها للإنتاج. تظهر رسالة: "البضاعة لم تُسجَّل في المستودع بعد"

### س: إذا كان الفرق في الفاتورة كبير؟
**ج:** يتم عرض تحذير للمدير ويجب الموافقة عليه قبل الدفع

### س: هل يمكن تعديل بيانات بعد التسجيل؟
**ج:** لا، إذا كنت تريد تعديل يمكنك تقفيل الشحنة أولاً ثم فتح القفل

### س: ماذا لو رفضنا الفاتورة؟
**ج:** يتم تحديث حالة الفاتورة إلى "rejected" وترجع للمورد للتصحيح

### س: هل هناك سجل للقرارات السابقة؟
**ج:** نعم، جدول reconciliation_logs يسجل كل القرارات مع التفاصيل

### س: كيف أشوف تقرير الموردين؟
**ج:** اذهب إلى 📊 تقرير الموردين من لوحة التسوية

---

## 🔧 Troubleshooting

### المشكلة: الأوزان ما تظهر في الجدول

**الحل:**
```php
// تأكد من وجود البيانات في قاعدة البيانات
php artisan tinker
DeliveryNote::where('actual_weight', '!=', null)->get();
```

### المشكلة: الـ Foreign Keys ما تشتغل

**الحل:**
```php
// تأكد من تفعيل الـ foreign keys
php artisan migrate:refresh
```

### المشكلة: الـ Routes ما تشتغل

**الحل:**
```php
// إعادة تحميل الـ routes
php artisan route:clear
php artisan route:cache
```

---

## 📝 ملاحظات تطويرية

### إذا أردت إضافة حقول جديدة:

1. أنشئ migration جديدة:
```bash
php artisan make:migration add_new_field_to_delivery_notes --table=delivery_notes
```

2. أضف الحقول:
```php
Schema::table('delivery_notes', function (Blueprint $table) {
    $table->string('new_field')->nullable();
});
```

3. حدّث الـ Model
4. حدّث الـ Views إذا لزم الأمر

### إذا أردت تغيير الفئات:

عدّل في `ReconciliationController.php`:

```php
// في method link():
if (abs($discrepancyPercentage) <= 1) {
    // غيّر الرقم حسب احتياجك
    $deliveryNote->update(['reconciliation_status' => 'matched']);
}
```

---

## 📞 الدعم الفني

إذا واجهت مشكلة:

1. تحقق من الـ error logs:
```bash
tail -f storage/logs/laravel.log
```

2. تحقق من قاعدة البيانات:
```bash
php artisan tinker
DeliveryNote::latest()->first();
```

3. اتصل بفريق التطوير مع:
   - رقم الخطأ
   - الخطوات للتكرار
   - لقطة شاشة للخطأ

---

## ✅ Checklist قبل الاستخدام

- [ ] تشغيل الـ migrations بنجاح
- [ ] إنشاء جميع الـ Models
- [ ] إنشاء جميع الـ Controllers
- [ ] إنشاء جميع الـ Views
- [ ] إضافة الـ Routes
- [ ] إضافة الـ Navigation links
- [ ] اختبار التسجيل (happy path)
- [ ] اختبار التسوية (happy path)
- [ ] اختبار المسارات الخاطئة
- [ ] اختبار الأداء مع بيانات كبيرة

---

**آخر تحديث:** 17 نوفمبر 2025  
**الإصدار:** 1.0  
**الحالة:** ✅ جاهز للإنتاج
