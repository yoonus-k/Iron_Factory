# 📊 نظام تتبع الباركود - شرح كامل

## 🎯 الهدف
تتبع المواد من دخول المستودع إلى مراحل الإنتاج المختلفة باستخدام نظام باركود متكامل.

---

## 📦 مراحل التتبع

### المرحلة 1️⃣: دخول المستودع
**عند تسجيل شحنة جديدة في المستودع:**

```php
// يتم إنشاء:
MaterialBatch {
    batch_code: "RW-2025-001",  // ✅ باركود دخول المستودع
    initial_quantity: 1000,
    available_quantity: 1000,
    status: 'available'
}

DeliveryNote {
    batch_id: 1,
    quantity: 1000
}
```

**ما يُحفظ:**
- ✅ `material_batches.batch_code` = باركود المستودع
- ✅ `delivery_notes.batch_id` = ربط مع الدفعة

---

### المرحلة 2️⃣: النقل للإنتاج
**عند نقل كمية للإنتاج (مثلاً 300 كجم):**

```php
// يتم إنشاء باركود جديد للإنتاج:
production_barcode = "PR-2025-001"

// يتم التحديث:
MaterialBatch {
    batch_code: "RW-2025-001",           // الأصلي (لا يتغير)
    latest_production_barcode: "PR-2025-001", // ✅ آخر باركود إنتاج
    available_quantity: 700,              // 1000 - 300
    status: 'in_production'
}

DeliveryNote {
    production_barcode: "PR-2025-001",    // ✅ باركود الإنتاج
    quantity_used: 300,
    quantity_remaining: 700
}

ProductTracking {
    barcode: "PR-2025-001",               // ✅ الباركود الرئيسي
    input_barcode: "RW-2025-001",        // ✅ من أين جاء (المستودع)
    output_barcode: "PR-2025-001",       // ✅ إلى أين ذهب (الإنتاج)
    stage: 'warehouse',
    action: 'transferred_to_production',
    input_weight: 300,
    metadata: {
        original_barcode: "RW-2025-001",
        production_barcode: "PR-2025-001",
        batch_id: 1,
        delivery_note_id: 5
    }
}
```

---

### المرحلة 3️⃣: مراحل الإنتاج التالية
**عند معالجة المادة في الإنتاج:**

```php
// مرحلة 1: القطع
ProductTracking {
    barcode: "PR-2025-002",              // باركود جديد للمرحلة
    input_barcode: "PR-2025-001",       // من المرحلة السابقة
    output_barcode: "PR-2025-002",      // للمرحلة التالية
    stage: 'cutting',
    input_weight: 300,
    output_weight: 290,
    waste_amount: 10
}

// مرحلة 2: التشكيل
ProductTracking {
    barcode: "PR-2025-003",
    input_barcode: "PR-2025-002",
    output_barcode: "PR-2025-003",
    stage: 'forming',
    input_weight: 290,
    output_weight: 285,
    waste_amount: 5
}
```

---

## 🔍 كيفية التتبع

### 1. التتبع من المنتج النهائي للمادة الخام

```php
// باستخدام الدالة traceBack()
$chain = ProductTracking::traceBack('PR-2025-003');

// النتيجة:
[
    { barcode: 'PR-2025-003', stage: 'forming', input: 'PR-2025-002' },
    { barcode: 'PR-2025-002', stage: 'cutting', input: 'PR-2025-001' },
    { barcode: 'PR-2025-001', stage: 'warehouse', input: 'RW-2025-001' }
]

// الآن يمكنك الوصول للمصدر الأصلي:
$originalBatch = MaterialBatch::where('batch_code', 'RW-2025-001')->first();
```

### 2. التتبع من المادة الخام للأمام

```php
// البحث عن جميع مراحل منتج معين
$history = ProductTracking::where('input_barcode', 'RW-2025-001')
    ->orWhere('barcode', 'RW-2025-001')
    ->orderBy('created_at')
    ->get();

// أو استخدام الدالة المخصصة:
$history = ProductTracking::getProductHistory('RW-2025-001');
```

### 3. التتبع من الدفعة (Batch)

```php
// الحصول على جميع عمليات النقل للإنتاج من دفعة معينة
$batch = MaterialBatch::find(1);

// البحث في product_tracking
$allProductionBarcodes = ProductTracking::whereJsonContains('metadata->batch_id', 1)->get();

// الحصول على آخر باركود إنتاج
$latestProductionBarcode = $batch->latest_production_barcode;

// الحصول على جميع أذونات التسليم المرتبطة
$deliveryNotes = DeliveryNote::where('batch_id', 1)->get();
```

---

## ✅ مزايا هذه الطريقة

### 1. **التتبع الكامل** 🔍
- يمكنك تتبع المنتج من النهاية للبداية
- يمكنك تتبع المادة من البداية للنهاية
- جميع المراحل موثقة في `product_tracking`

### 2. **الربط المزدوج** 🔗
- `material_batches` يحتفظ بالباركود الأصلي + آخر باركود إنتاج
- `delivery_notes` يحتفظ بباركود الإنتاج المرتبط بكل نقل
- `product_tracking` يحتفظ بسلسلة كاملة من الباركودات

### 3. **المرونة** 💪
- يمكن نقل كميات جزئية من نفس الدفعة
- كل عملية نقل تحصل على باركود إنتاج فريد
- التاريخ الكامل محفوظ في metadata

### 4. **سهولة الاستعلام** 📊
```php
// الحصول على كل المنتجات من دفعة معينة
$batch = MaterialBatch::with(['deliveryNotes'])->find(1);
$productionBarcodes = $batch->deliveryNotes->pluck('production_barcode');

// الحصول على تاريخ باركود معين
$report = ProductTracking::fullReport('PR-2025-001');
```

---

## 🎯 سيناريو عملي كامل

### الخطوة 1: وصول الشحنة
```
📦 وصل 1000 كجم حديد من المورد
└─ يُنشأ batch_code: "RW-2025-001"
```

### الخطوة 2: النقل الأول للإنتاج (300 كجم)
```
📦 RW-2025-001 (1000 كجم)
└─ 🏭 PR-2025-001 (300 كجم) ← نُقل للإنتاج
└─ 📦 700 كجم متبقي
```

### الخطوة 3: النقل الثاني للإنتاج (400 كجم)
```
📦 RW-2025-001 (700 كجم)
├─ 🏭 PR-2025-001 (300 كجم) ← تم سابقاً
├─ 🏭 PR-2025-005 (400 كجم) ← نُقل اليوم
└─ 📦 300 كجم متبقي
```

### الخطوة 4: مراحل الإنتاج
```
🏭 PR-2025-001 (300 كجم)
├─ ✂️ PR-2025-002 (290 كجم) ← بعد القطع
├─ 🔨 PR-2025-003 (285 كجم) ← بعد التشكيل
└─ ✅ PR-2025-004 (280 كجم) ← منتج نهائي
```

---

## 📝 الخلاصة

### الطريقة الحالية صحيحة ✅ وتوفر:

1. **ثلاث مستويات من الحفظ:**
   - `material_batches`: الباركود الأصلي + آخر باركود إنتاج
   - `delivery_notes`: باركود الإنتاج لكل عملية نقل
   - `product_tracking`: السلسلة الكاملة مع التفاصيل

2. **تتبع كامل:**
   - من المنتج النهائي → المادة الخام ✅
   - من المادة الخام → جميع المنتجات ✅
   - جميع المراحل الوسيطة ✅

3. **مرونة عالية:**
   - دعم النقل الجزئي ✅
   - دعم تعدد مراحل الإنتاج ✅
   - حفظ التاريخ الكامل ✅

**نعم، يمكنك التتبع بشكل كامل فيما بعد! 🎯**
