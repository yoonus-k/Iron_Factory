<?php

namespace App\Http\Controllers\Modules\\Manufacturing\\Http\\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class \FinishedProductDeliveryController extends Controller
{
    //
}
