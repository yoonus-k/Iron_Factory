<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\DeliveryNote;
use Modules\Manufacturing\Entities\MaterialBatch;

class ProductionConfirmation extends Model
{
    use HasFactory;

    protected $table = 'production_confirmations';

    protected $fillable = [
        'delivery_note_id',
        'batch_id',
        'stage_code',
        'assigned_to',
        'status',
        'confirmed_by',
        'confirmed_at',
        'rejected_by',
        'rejected_at',
        'rejection_reason',
        'actual_received_quantity',
        'notes',
        'ip_address',
        'user_agent',
    ];

    protected $casts = [
        'confirmed_at' => 'datetime',
        'rejected_at' => 'datetime',
        'actual_received_quantity' => 'decimal:2',
    ];

    /**
     * العلاقة مع أذن التسليم
     */
    public function deliveryNote(): BelongsTo
    {
        return $this->belongsTo(DeliveryNote::class);
    }

    /**
     * العلاقة مع الدفعة
     */
    public function batch(): BelongsTo
    {
        return $this->belongsTo(MaterialBatch::class);
    }

    /**
     * العلاقة مع الموظف المكلف
     */
    public function assignedUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    /**
     * العلاقة مع الموظف الذي أكد
     */
    public function confirmedByUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'confirmed_by');
    }

    /**
     * العلاقة مع الموظف الذي رفض
     */
    public function rejectedByUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'rejected_by');
    }

    /**
     * العلاقة مع المرحلة
     */
    public function stage()
    {
        return ProductionStage::where('stage_code', $this->stage_code)->first();
    }

    /**
     * Scopes
     */
    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeConfirmed($query)
    {
        return $query->where('status', 'confirmed');
    }

    public function scopeRejected($query)
    {
        return $query->where('status', 'rejected');
    }

    public function scopeForUser($query, $userId)
    {
        return $query->where('assigned_to', $userId);
    }

    /**
     * الحصول على الطلبات المعلقة لموظف معين
     */
    public static function getPendingForUser($userId)
    {
        return self::with(['deliveryNote', 'batch', 'assignedUser'])
            ->pending()
            ->forUser($userId)
            ->orderBy('created_at', 'desc')
            ->get();
    }

    /**
     * تأكيد الاستلام
     */
    public function confirm($userId, $actualQuantity = null, $notes = null)
    {
        $this->update([
            'status' => 'confirmed',
            'confirmed_by' => $userId,
            'confirmed_at' => now(),
            'actual_received_quantity' => $actualQuantity ?? $this->actual_received_quantity,
            'notes' => $notes,
        ]);

        // تحديث حالة الدفعة
        if ($this->batch) {
            $this->batch->update([
                'status' => 'in_production',
            ]);
        }
        
        // تحديث حالة أذن التسليم فقط إذا تم تأكيد جميع الكويلات
        $this->updateDeliveryNoteStatusIfAllConfirmed();
    }
    
    /**
     * تحديث حالة أذن التسليم إذا تم تأكيد جميع الكويلات
     */
    private function updateDeliveryNoteStatusIfAllConfirmed()
    {
        // التحقق من جميع التأكيدات المرتبطة بنفس أذن التسليم
        $allConfirmations = self::where('delivery_note_id', $this->delivery_note_id)->get();
        $allConfirmed = $allConfirmations->every(fn($c) => $c->status === 'confirmed');
        
        if ($allConfirmed) {
            $this->deliveryNote->update([
                'transfer_status' => 'confirmed',
                'confirmed_by' => $this->confirmed_by,
                'confirmed_at' => $this->confirmed_at,
            ]);
        }
    }

    /**
     * رفض الاستلام
     */
    public function reject($userId, $reason)
    {
        $this->update([
            'status' => 'rejected',
            'rejected_by' => $userId,
            'rejected_at' => now(),
            'rejection_reason' => $reason,
        ]);

        // تحديث حالة أذن التسليم (فقط إذا كانت جميع الكويلات مرفوضة)
        $this->deliveryNote->update([
            'transfer_status' => 'rejected',
            'rejected_by' => $userId,
            'rejected_at' => now(),
            'rejection_reason' => $reason,
        ]);

        // ✅ إرجاع الكمية للمستودع (MaterialDetail)
        if ($this->deliveryNote && $this->deliveryNote->materialDetail) {
            $materialDetail = $this->deliveryNote->materialDetail;
            
            // إضافة الكمية المرفوضة مرة أخرى للمستودع
            $rejectedQuantity = $this->actual_received_quantity ?? $this->deliveryNote->quantity;
            $materialDetail->quantity += $rejectedQuantity;
            $materialDetail->save();
            
            \Log::info("تم إرجاع {$rejectedQuantity} كجم للمستودع بعد رفض الكويل", [
                'confirmation_id' => $this->id,
                'material_detail_id' => $materialDetail->id,
                'previous_quantity' => $materialDetail->quantity - $rejectedQuantity,
                'new_quantity' => $materialDetail->quantity,
            ]);
        }

        // ✅ إرجاع الكمية للـ batch وتغيير حالته
        if ($this->batch) {
            $rejectedQuantity = $this->actual_received_quantity ?? $this->deliveryNote->quantity;
            $this->batch->increment('available_quantity', $rejectedQuantity);
            $this->batch->update(['status' => 'available']);
            
            \Log::info("تم إرجاع {$rejectedQuantity} كجم للـ batch بعد رفض الكويل", [
                'confirmation_id' => $this->id,
                'batch_id' => $this->batch->id,
                'batch_code' => $this->batch->batch_code,
            ]);
        }
    }
}
