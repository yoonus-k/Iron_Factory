<?php

return [
    'name' => 'Manufacturing',
];
