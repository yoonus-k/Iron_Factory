<?php

namespace Modules\Manufacturing\Database\Seeders;

use Illuminate\Database\Seeder;

class ManufacturingDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $this->call([
            BarcodeSettingsSeeder::class,
        ]);
    }
}
